package com.example

import com.example.data.CurrencyUtils
import com.example.data.QrCodeGenerator
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {
    @Test
    fun currencyUtils_formatPaise_formatsCorrectly() {
        val formatted = CurrencyUtils.formatPaise(14500L)
        assertTrue(formatted.contains("145.00") || formatted.contains("145"))
    }

    @Test
    fun currencyUtils_parseRupeesToPaise_parsesValidInput() {
        val paise = CurrencyUtils.parseRupeesToPaise("250.50")
        assertEquals(25050L, paise)
    }

    @Test
    fun currencyUtils_calculateOrderPricePaise_accurate() {
        // 500 units at ₹180 per 1000 = ₹90
        val price = CurrencyUtils.calculateOrderPricePaise(500, 18000L)
        assertEquals(9000L, price)
    }

    @Test
    fun qrCodeGenerator_buildsValidUpiUri() {
        val uri = QrCodeGenerator.buildUpiUri(
            upiId = "rahmansmm@fam",
            payeeName = "MEGA SMM INDIA",
            amountPaise = 15000L,
            transactionNote = "Recharge Test"
        )
        assertTrue(uri.startsWith("upi://pay"))
        assertTrue(uri.contains("pa=rahmansmm%40fam") || uri.contains("pa=rahmansmm@fam"))
        assertTrue(uri.contains("am=150.00"))
        assertTrue(uri.contains("cu=INR"))
    }
}
