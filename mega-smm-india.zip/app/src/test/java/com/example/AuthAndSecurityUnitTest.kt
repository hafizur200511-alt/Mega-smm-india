package com.example

import com.example.data.CurrencyUtils
import com.example.data.FirebaseService
import com.example.model.UserProfile
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AuthAndSecurityUnitTest {

    @Test
    fun emailValidation_validAndInvalid() {
        val validEmails = listOf(
            "hafizur200511@gmail.com",
            "customer@megasmm.com",
            "user.name+tag@sub.domain.co.in"
        )
        val invalidEmails = listOf(
            "",
            "invalid",
            "@domain.com",
            "user@",
            "user @domain.com"
        )

        val emailRegex = Regex("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$")

        for (email in validEmails) {
            assertTrue("Expected valid: $email", emailRegex.matches(email))
        }
        for (email in invalidEmails) {
            assertFalse("Expected invalid: $email", emailRegex.matches(email))
        }
    }

    @Test
    fun passwordValidation_lengthRequirement() {
        fun isPasswordValid(password: String): Boolean = password.length >= 6

        assertTrue(isPasswordValid("123456"))
        assertTrue(isPasswordValid("StrongP@ssw0rd!"))
        assertFalse(isPasswordValid("12345"))
        assertFalse(isPasswordValid(""))
    }

    @Test
    fun adminAuthorization_onlyExplicitAuthorizedEmailsGranted() {
        val adminProfile1 = UserProfile(
            uid = "admin_uid_1",
            email = "hafizur200511@gmail.com",
            isAdmin = false // verified via email bootstrap set
        )
        val adminProfile2 = UserProfile(
            uid = "admin_uid_2",
            email = "admin@megasmm.in",
            isAdmin = true
        )
        val customerProfile = UserProfile(
            uid = "cust_uid",
            email = "regular_customer@gmail.com",
            isAdmin = false
        )
        val hackerProfile = UserProfile(
            uid = "hacker_uid",
            email = "attacker@evil.com",
            isAdmin = false // unverified customer cannot be admin
        )

        assertTrue(FirebaseService.isUserAdmin(adminProfile1))
        assertTrue(FirebaseService.isUserAdmin(adminProfile2))
        assertFalse(FirebaseService.isUserAdmin(customerProfile))
        assertFalse(FirebaseService.isUserAdmin(hackerProfile))
        assertFalse(FirebaseService.isUserAdmin(null))
    }

    @Test
    fun profilePreservation_doesNotOverwriteExistingBalances() {
        val existingProfile = UserProfile(
            uid = "user_123",
            email = "customer@example.com",
            displayName = "Original Name",
            photoUrl = "https://example.com/photo.jpg",
            walletBalancePaise = 250000L, // ₹2,500
            totalOrders = 12,
            isAdmin = false,
            createdAt = 1700000000000L
        )

        // Simulated login update with new display name
        val incomingDisplayName = "Updated Customer Name"
        val updatedProfile = existingProfile.copy(
            displayName = incomingDisplayName
        )

        // Assert critical balance and order history remained strictly preserved
        assertEquals(250000L, updatedProfile.walletBalancePaise)
        assertEquals(12, updatedProfile.totalOrders)
        assertEquals(1700000000000L, updatedProfile.createdAt)
        assertEquals("Updated Customer Name", updatedProfile.displayName)
    }

    @Test
    fun currencyCalculations_accurate() {
        // 1,000 units at ₹145 per 1,000 = ₹145.00 (14,500 paise)
        val cost1k = CurrencyUtils.calculateOrderPricePaise(1000, 14500L)
        assertEquals(14500L, cost1k)

        // 2,500 units at ₹42 per 1,000 = ₹105.00 (10,500 paise)
        val cost2k5 = CurrencyUtils.calculateOrderPricePaise(2500, 4200L)
        assertEquals(10500L, cost2k5)
    }
}
