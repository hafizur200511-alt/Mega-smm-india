package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import com.example.data.FirebaseService
import com.example.model.ServiceItem
import com.example.model.UserProfile
import com.example.ui.components.AppTab
import com.example.ui.components.FloatingGlassNavBar
import com.example.ui.components.LiquidGlassBackground
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.NewOrderSheet
import com.example.ui.screens.OrdersScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.ServicesScreen
import com.example.ui.screens.SplashScreen
import com.example.ui.screens.WalletScreen
import com.example.ui.screens.admin.AdminPanelScreen
import com.example.ui.theme.MyApplicationTheme
import com.google.firebase.auth.FirebaseAuth

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                MegaSmmApp()
            }
        }
    }
}

@Composable
fun MegaSmmApp() {
    val context = LocalContext.current
    var screenState by remember { mutableStateOf(ScreenState.SPLASH) }
    var selectedTab by remember { mutableStateOf(AppTab.HOME) }
    var orderSheetService by remember { mutableStateOf<ServiceItem?>(null) }

    var authUser by remember { mutableStateOf(FirebaseService.currentUser) }

    // Listen to Firebase Auth state changes
    DisposableEffect(Unit) {
        val listener = FirebaseAuth.AuthStateListener { auth ->
            val u = auth.currentUser
            authUser = u
            if (u == null && screenState != ScreenState.SPLASH) {
                screenState = ScreenState.AUTH
            }
        }
        FirebaseService.auth.addAuthStateListener(listener)
        onDispose {
            FirebaseService.auth.removeAuthStateListener(listener)
        }
    }

    val currentUid = authUser?.uid ?: ""
    val userProfile by FirebaseService.observeUserProfile(currentUid).collectAsState(initial = null)
    val services by FirebaseService.observeServices().collectAsState(initial = FirebaseService.DEFAULT_SERVICES)
    val orders by FirebaseService.observeUserOrders(currentUid).collectAsState(initial = emptyList())
    val paymentRequests by FirebaseService.observeUserPaymentRequests(currentUid).collectAsState(initial = emptyList())
    val upiSettings by FirebaseService.observeUpiSettings().collectAsState(initial = com.example.model.UpiSettings())
    val announcements by FirebaseService.observeAnnouncements().collectAsState(initial = emptyList())

    val pendingOrdersCount = orders.count { it.status == "PENDING" || it.status == "PROCESSING" }

    // Enforce authentication gate: if user is not authenticated and past splash, force AUTH
    LaunchedEffect(authUser, screenState) {
        if (authUser == null && screenState != ScreenState.SPLASH && screenState != ScreenState.AUTH) {
            screenState = ScreenState.AUTH
        }
    }

    // Enforce admin verification gate: if in ADMIN screen but not admin, revert to MAIN
    LaunchedEffect(screenState, userProfile) {
        if (screenState == ScreenState.ADMIN && userProfile != null && !FirebaseService.isUserAdmin(userProfile)) {
            Toast.makeText(context, "Access Denied: Administrator privileges required.", Toast.LENGTH_SHORT).show()
            screenState = ScreenState.MAIN
        }
    }

    LiquidGlassBackground(
        modifier = Modifier.fillMaxSize()
    ) {
        AnimatedContent(
            targetState = screenState,
            transitionSpec = { fadeIn() togetherWith fadeOut() },
            label = "screen_transition"
        ) { targetScreen ->
            when (targetScreen) {
                ScreenState.SPLASH -> {
                    SplashScreen(
                        onNavigateToHome = {
                            if (FirebaseService.currentUser != null) {
                                screenState = ScreenState.MAIN
                            } else {
                                screenState = ScreenState.AUTH
                            }
                        },
                        onNavigateToAuth = { screenState = ScreenState.AUTH }
                    )
                }

                ScreenState.AUTH -> {
                    AuthScreen(
                        onAuthSuccess = {
                            screenState = ScreenState.MAIN
                        }
                    )
                }

                ScreenState.ADMIN -> {
                    AdminPanelScreen(
                        userProfile = userProfile,
                        onNavigateBack = { screenState = ScreenState.MAIN }
                    )
                }

                ScreenState.MAIN -> {
                    if (orderSheetService != null) {
                        BackHandler { orderSheetService = null }
                    } else if (selectedTab != AppTab.HOME) {
                        BackHandler { selectedTab = AppTab.HOME }
                    }

                    Scaffold(
                        modifier = Modifier.fillMaxSize(),
                        containerColor = Color.Transparent,
                        bottomBar = {
                            FloatingGlassNavBar(
                                selectedTab = selectedTab,
                                onTabSelected = { selectedTab = it },
                                unreadOrdersCount = pendingOrdersCount
                            )
                        }
                    ) { innerPadding ->
                        Box(modifier = Modifier.fillMaxSize()) {
                            when (selectedTab) {
                                AppTab.HOME -> {
                                    HomeScreen(
                                        userProfile = userProfile,
                                        services = services,
                                        announcements = announcements,
                                        onTabSelected = { selectedTab = it },
                                        onAdminClick = {
                                            if (FirebaseService.isUserAdmin(userProfile)) {
                                                screenState = ScreenState.ADMIN
                                            } else {
                                                Toast.makeText(context, "Administrator access required.", Toast.LENGTH_SHORT).show()
                                            }
                                        },
                                        onServiceOrderClick = { service ->
                                            orderSheetService = service
                                        }
                                    )
                                }

                                AppTab.SERVICES -> {
                                    ServicesScreen(
                                        services = services,
                                        userProfile = userProfile,
                                        onSelectService = { service ->
                                            orderSheetService = service
                                        }
                                    )
                                }

                                AppTab.ORDERS -> {
                                    OrdersScreen(
                                        orders = orders,
                                        onExploreServices = { selectedTab = AppTab.SERVICES }
                                    )
                                }

                                AppTab.WALLET -> {
                                    WalletScreen(
                                        userProfile = userProfile,
                                        upiSettings = upiSettings,
                                        paymentRequests = paymentRequests,
                                        onPaymentSubmitted = {}
                                    )
                                }

                                AppTab.PROFILE -> {
                                    ProfileScreen(
                                        userProfile = userProfile,
                                        onSignOut = {
                                            FirebaseService.signOut(context) {
                                                screenState = ScreenState.AUTH
                                            }
                                        },
                                        onAdminClick = {
                                            if (FirebaseService.isUserAdmin(userProfile)) {
                                                screenState = ScreenState.ADMIN
                                            } else {
                                                Toast.makeText(context, "Administrator access required.", Toast.LENGTH_SHORT).show()
                                            }
                                        }
                                    )
                                }
                            }

                            // New Order Sheet dialog if opened
                            if (orderSheetService != null) {
                                NewOrderSheet(
                                    services = services,
                                    initialService = orderSheetService,
                                    userProfile = userProfile,
                                    onDismiss = { orderSheetService = null },
                                    onOrderPlaced = {
                                        orderSheetService = null
                                        selectedTab = AppTab.ORDERS
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
