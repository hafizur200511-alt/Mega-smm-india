package com.example.model

data class WalletTransaction(
    val id: String = "",
    val userId: String = "",
    val amountPaise: Long = 0L,
    val type: String = "CREDIT", // CREDIT, DEBIT
    val description: String = "",
    val referenceId: String = "",
    val balanceAfterPaise: Long = 0L,
    val timestamp: Long = System.currentTimeMillis()
)
