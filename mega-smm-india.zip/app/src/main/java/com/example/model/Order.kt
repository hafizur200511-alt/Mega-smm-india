package com.example.model

data class Order(
    val id: String = "",
    val userId: String = "",
    val userEmail: String = "",
    val serviceId: String = "",
    val serviceName: String = "",
    val platform: String = "",
    val targetUrl: String = "",
    val quantity: Int = 0,
    val totalAmountPaise: Long = 0L,
    val status: String = "PENDING", // PENDING, PROCESSING, COMPLETED, CANCELLED
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
