package com.example.model

data class UserProfile(
    val uid: String = "",
    val email: String = "",
    val displayName: String = "",
    val photoUrl: String = "",
    val walletBalancePaise: Long = 0L,
    val totalOrders: Int = 0,
    val isAdmin: Boolean = false,
    val isSuspended: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)
