package com.example.model

data class ServiceItem(
    val id: String = "",
    val name: String = "",
    val platform: String = "Instagram",
    val category: String = "Followers",
    val description: String = "",
    val pricePerThousandPaise: Long = 0L,
    val minQuantity: Int = 50,
    val maxQuantity: Int = 100000,
    val deliveryInfo: String = "Instant start • High Speed • Refill guaranteed",
    val providerMode: String = "MANUAL",
    val providerServiceId: String = "",
    val isActive: Boolean = true,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
