package com.example.model

data class UpiSettings(
    val upiId: String = "rahmansmm@fam",
    val payeeName: String = "MEGA SMM INDIA",
    val minRechargePaise: Long = 1000L, // Rs 10
    val maxRechargePaise: Long = 5000000L, // Rs 50,000
    val instructions: String = "Pay using any UPI app (GPay, PhonePe, Paytm), copy the 12-digit UTR / Reference number, and submit below for instant verification.",
    val isManualPaymentEnabled: Boolean = true,
    val supportInstagram: String = "megasmmindia",
    val updatedAt: Long = System.currentTimeMillis()
)
