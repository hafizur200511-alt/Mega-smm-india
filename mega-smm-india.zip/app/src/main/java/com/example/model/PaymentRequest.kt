package com.example.model

data class PaymentRequest(
    val id: String = "",
    val userId: String = "",
    val userEmail: String = "",
    val amountPaise: Long = 0L,
    val upiIdUsed: String = "",
    val transactionReference: String = "", // UTR
    val proofImageUrl: String = "",
    val status: String = "PENDING", // PENDING, APPROVED, REJECTED
    val rejectionReason: String = "",
    val reviewedBy: String = "",
    val reviewedAt: Long = 0L,
    val createdAt: Long = System.currentTimeMillis()
)
