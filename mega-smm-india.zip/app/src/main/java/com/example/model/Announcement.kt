package com.example.model

data class Announcement(
    val id: String = "",
    val title: String = "",
    val message: String = "",
    val type: String = "INFO",
    val isActive: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)
