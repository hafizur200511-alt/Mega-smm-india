package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.Numbers
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.CurrencyUtils
import com.example.data.FirebaseService
import com.example.model.ServiceItem
import com.example.model.UserProfile
import com.example.ui.components.GlassButton
import com.example.ui.components.GlassTextField
import com.example.ui.components.PlatformIconBadge
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.CardBackgroundGlass
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.LiquidGlassSpecularBorder
import com.example.ui.theme.PrimaryBlue
import com.example.ui.theme.SilverBorder
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextDim
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NewOrderSheet(
    services: List<ServiceItem>,
    initialService: ServiceItem? = null,
    userProfile: UserProfile?,
    onDismiss: () -> Unit,
    onOrderPlaced: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var selectedService by remember {
        mutableStateOf(initialService ?: services.firstOrNull() ?: FirebaseService.DEFAULT_SERVICES.first())
    }
    var targetUrl by remember { mutableStateOf("") }
    var quantityText by remember { mutableStateOf(selectedService.minQuantity.toString()) }
    var isSubmitting by remember { mutableStateOf(false) }

    val quantity = quantityText.toIntOrNull() ?: 0
    val totalCostPaise = CurrencyUtils.calculateOrderPricePaise(quantity, selectedService.pricePerThousandPaise)
    val hasEnoughBalance = (userProfile?.walletBalancePaise ?: 0L) >= totalCostPaise

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = Color(0xF00A132C),
        dragHandle = null
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp, vertical = 20.dp)
                .verticalScroll(rememberScrollState())
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    PlatformIconBadge(platform = selectedService.platform)
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "New SMM Order",
                            color = TextWhite,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${selectedService.platform} • ${selectedService.category}",
                            color = AccentCyan,
                            fontSize = 12.sp
                        )
                    }
                }
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Filled.Close, contentDescription = "Close", tint = TextMuted)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Service details box
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0x330E1F42))
                    .border(1.dp, SilverBorder, RoundedCornerShape(16.dp))
                    .padding(14.dp)
            ) {
                Column {
                    Text(
                        text = selectedService.name,
                        color = TextWhite,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 13.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = selectedService.description,
                        color = TextMuted,
                        fontSize = 11.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Rate: ${CurrencyUtils.formatPaise(selectedService.pricePerThousandPaise)} / 1K",
                            color = AccentCyan,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Min: ${selectedService.minQuantity} | Max: ${selectedService.maxQuantity}",
                            color = TextDim,
                            fontSize = 11.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Target URL
            GlassTextField(
                value = targetUrl,
                onValueChange = { targetUrl = it },
                label = "Target Link / Post URL / Username",
                placeholder = "https://instagram.com/your_profile",
                leadingIcon = Icons.Filled.Link,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Quantity
            GlassTextField(
                value = quantityText,
                onValueChange = { quantityText = it.filter { char -> char.isDigit() } },
                label = "Order Quantity",
                placeholder = "Min: ${selectedService.minQuantity}",
                leadingIcon = Icons.Filled.Numbers,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Cost calculation summary
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(Brush.linearGradient(listOf(Color(0x2E0072FE), Color(0x1A00F5FF))))
                    .border(1.dp, LiquidGlassSpecularBorder, RoundedCornerShape(16.dp))
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Total Amount", color = TextMuted, fontSize = 12.sp)
                        Text(
                            text = CurrencyUtils.formatPaise(totalCostPaise),
                            color = TextWhite,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("Wallet Balance", color = TextMuted, fontSize = 12.sp)
                        Text(
                            text = CurrencyUtils.formatPaise(userProfile?.walletBalancePaise ?: 0L),
                            color = if (hasEnoughBalance) SuccessGreen else ErrorRed,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            GlassButton(
                text = if (hasEnoughBalance) "Confirm & Launch Order" else "Insufficient Balance - Add Funds",
                onClick = {
                    if (targetUrl.isBlank()) {
                        Toast.makeText(context, "Please enter target link/username", Toast.LENGTH_SHORT).show()
                        return@GlassButton
                    }
                    if (quantity < selectedService.minQuantity || quantity > selectedService.maxQuantity) {
                        Toast.makeText(context, "Quantity must be between ${selectedService.minQuantity} and ${selectedService.maxQuantity}", Toast.LENGTH_SHORT).show()
                        return@GlassButton
                    }
                    if (!hasEnoughBalance) {
                        Toast.makeText(context, "Please recharge your wallet via UPI first", Toast.LENGTH_SHORT).show()
                        return@GlassButton
                    }

                    isSubmitting = true
                    scope.launch {
                        val uid = userProfile?.uid ?: FirebaseService.currentUser?.uid ?: ""
                        if (uid.isBlank()) {
                            Toast.makeText(context, "Please sign in to place an order", Toast.LENGTH_SHORT).show()
                            isSubmitting = false
                            return@launch
                        }
                        val email = userProfile?.email ?: FirebaseService.currentUser?.email ?: ""
                        val res = FirebaseService.placeOrder(
                            userId = uid,
                            userEmail = email,
                            serviceId = selectedService.id,
                            targetUrl = targetUrl,
                            quantity = quantity
                        )
                        isSubmitting = false
                        if (res.isSuccess) {
                            Toast.makeText(context, "Order placed successfully! 🚀", Toast.LENGTH_SHORT).show()
                            onOrderPlaced()
                            onDismiss()
                        } else {
                            Toast.makeText(context, res.exceptionOrNull()?.message ?: "Failed", Toast.LENGTH_SHORT).show()
                        }
                    }
                },
                enabled = !isSubmitting,
                isLoading = isSubmitting,
                icon = Icons.Filled.RocketLaunch,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(14.dp))
        }
    }
}
