package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.CurrencyUtils
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.BackgroundDark
import com.example.ui.theme.BackgroundDarkSecondary
import com.example.ui.theme.CardBackgroundGlass
import com.example.ui.theme.CrownGold
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.FacebookBlue
import com.example.ui.theme.GlassCardGlow
import com.example.ui.theme.InstagramGradient
import com.example.ui.theme.LiquidCyanOrb
import com.example.ui.theme.LiquidElectricBlue
import com.example.ui.theme.LiquidGlassSpecularBorder
import com.example.ui.theme.LiquidPinkOrb
import com.example.ui.theme.LiquidPurpleOrb
import com.example.ui.theme.PrimaryBlue
import com.example.ui.theme.PrimaryButtonGradient
import com.example.ui.theme.SilverBorder
import com.example.ui.theme.SilverBorderHighlight
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TelegramCyan
import com.example.ui.theme.TextDim
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite
import com.example.ui.theme.WarningAmber
import com.example.ui.theme.YouTubeRed
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun LiquidGlassBackground(
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit
) {
    val transition = rememberInfiniteTransition(label = "liquid_orbs")

    val phase1 by transition.animateFloat(
        initialValue = 0f,
        targetValue = 6.28318f,
        animationSpec = infiniteRepeatable(
            animation = tween(14000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "phase1"
    )

    val phase2 by transition.animateFloat(
        initialValue = 0f,
        targetValue = 6.28318f,
        animationSpec = infiniteRepeatable(
            animation = tween(19000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "phase2"
    )

    val pulse by transition.animateFloat(
        initialValue = 0.85f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(5000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(BackgroundDark)
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height

            // Orb 1: Cyan floating top-left to center
            val orb1X = w * 0.25f + cos(phase1) * (w * 0.15f)
            val orb1Y = h * 0.22f + sin(phase1) * (h * 0.10f)
            val orb1R = (w * 0.55f) * pulse

            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        LiquidCyanOrb.copy(alpha = 0.22f),
                        LiquidCyanOrb.copy(alpha = 0.08f),
                        Color.Transparent
                    ),
                    center = Offset(orb1X, orb1Y),
                    radius = orb1R
                ),
                radius = orb1R,
                center = Offset(orb1X, orb1Y)
            )

            // Orb 2: Deep Purple/Indigo floating center-right
            val orb2X = w * 0.78f - sin(phase2) * (w * 0.18f)
            val orb2Y = h * 0.45f + cos(phase2) * (h * 0.12f)
            val orb2R = w * 0.65f

            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        LiquidPurpleOrb.copy(alpha = 0.24f),
                        LiquidPurpleOrb.copy(alpha = 0.07f),
                        Color.Transparent
                    ),
                    center = Offset(orb2X, orb2Y),
                    radius = orb2R
                ),
                radius = orb2R,
                center = Offset(orb2X, orb2Y)
            )

            // Orb 3: Electric Blue undulating bottom
            val orb3X = w * 0.40f + cos(phase2 * 0.8f) * (w * 0.20f)
            val orb3Y = h * 0.82f + sin(phase1 * 0.7f) * (h * 0.08f)
            val orb3R = w * 0.70f

            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        LiquidElectricBlue.copy(alpha = 0.20f),
                        PrimaryBlue.copy(alpha = 0.06f),
                        Color.Transparent
                    ),
                    center = Offset(orb3X, orb3Y),
                    radius = orb3R
                ),
                radius = orb3R,
                center = Offset(orb3X, orb3Y)
            )

            // Orb 4: Subtle pink highlight drifting top-right
            val orb4X = w * 0.85f + cos(phase1) * (w * 0.10f)
            val orb4Y = h * 0.15f - sin(phase2) * (h * 0.08f)
            val orb4R = w * 0.45f

            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        LiquidPinkOrb.copy(alpha = 0.12f),
                        Color.Transparent
                    ),
                    center = Offset(orb4X, orb4Y),
                    radius = orb4R
                ),
                radius = orb4R,
                center = Offset(orb4X, orb4Y)
            )

            // Dark OLED Vignette
            drawRect(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color.Transparent,
                        BackgroundDark.copy(alpha = 0.65f)
                    ),
                    center = Offset(w * 0.5f, h * 0.5f),
                    radius = (w.coerceAtLeast(h)) * 0.85f
                )
            )
        }

        content()
    }
}

@Composable
fun LiquidPulseDot(
    modifier: Modifier = Modifier,
    color: Color = AccentCyan
) {
    val transition = rememberInfiniteTransition(label = "pulse_dot")
    val scale by transition.animateFloat(
        initialValue = 0.7f,
        targetValue = 1.25f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "dot_scale"
    )

    Box(
        modifier = modifier
            .size(8.dp)
            .scale(scale)
            .clip(CircleShape)
            .background(color)
    )
}

@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(24.dp),
    backgroundColor: Color = CardBackgroundGlass,
    borderBrush: Brush = LiquidGlassSpecularBorder,
    borderColor: Color? = null,
    borderWidth: Dp = 1.dp,
    elevation: Dp = 12.dp,
    content: @Composable () -> Unit
) {
    val actualBorder = if (borderColor != null) {
        Brush.linearGradient(
            colors = listOf(
                borderColor.copy(alpha = 0.8f),
                borderColor.copy(alpha = 0.2f),
                Color(0x33FFFFFF)
            )
        )
    } else {
        borderBrush
    }

    Box(
        modifier = modifier
            .shadow(
                elevation = elevation,
                shape = shape,
                ambientColor = GlassCardGlow.copy(alpha = 0.2f),
                spotColor = PrimaryBlue.copy(alpha = 0.25f)
            )
            .clip(shape)
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        backgroundColor.copy(alpha = 0.85f),
                        backgroundColor.copy(alpha = 0.60f)
                    )
                )
            )
            .border(borderWidth, actualBorder, shape)
    ) {
        // Specular top glare overlay
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(40.dp)
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color(0x1AFFFFFF),
                            Color.Transparent
                        )
                    )
                )
        )
        content()
    }
}

@Composable
fun GlassButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    isSecondary: Boolean = false,
    enabled: Boolean = true,
    isLoading: Boolean = false
) {
    val shape = RoundedCornerShape(18.dp)

    Box(
        modifier = modifier
            .height(52.dp)
            .clip(shape)
            .shadow(if (isSecondary) 0.dp else 12.dp, shape, spotColor = AccentCyan.copy(alpha = 0.3f))
            .background(if (isSecondary) SolidColor(Color(0x330E1F42)) else PrimaryButtonGradient)
            .border(
                1.dp,
                if (isSecondary) SolidColor(SilverBorder) else Brush.linearGradient(listOf(Color(0x80FFFFFF), Color.Transparent)),
                shape
            )
            .clickable(enabled = enabled && !isLoading) { onClick() }
            .padding(horizontal = 20.dp),
        contentAlignment = Alignment.Center
    ) {
        if (isLoading) {
            CircularProgressIndicator(
                modifier = Modifier.size(22.dp),
                color = TextWhite,
                strokeWidth = 2.dp
            )
        } else {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                if (icon != null) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = TextWhite,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                }
                Text(
                    text = text,
                    color = TextWhite,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
            }
        }
    }
}

@Composable
fun GlassSecondaryButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    enabled: Boolean = true
) {
    GlassButton(
        text = text,
        onClick = onClick,
        modifier = modifier,
        icon = icon,
        isSecondary = true,
        enabled = enabled
    )
}

@Composable
fun GlassTextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    placeholder: String = "",
    leadingIcon: ImageVector? = null,
    trailingIcon: @Composable (() -> Unit)? = null,
    keyboardOptions: KeyboardOptions = KeyboardOptions.Default,
    visualTransformation: VisualTransformation = VisualTransformation.None,
    isError: Boolean = false,
    errorMessage: String? = null,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier) {
        Text(
            text = label,
            color = TextMuted,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.padding(bottom = 6.dp)
        )
        OutlinedTextField(
            value = value,
            onValueChange = onValueChange,
            placeholder = { Text(placeholder, color = TextDim, fontSize = 14.sp) },
            leadingIcon = leadingIcon?.let {
                { Icon(it, contentDescription = null, tint = AccentCyan, modifier = Modifier.size(20.dp)) }
            },
            trailingIcon = trailingIcon,
            singleLine = true,
            isError = isError,
            keyboardOptions = keyboardOptions,
            visualTransformation = visualTransformation,
            shape = RoundedCornerShape(16.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = CardBackgroundGlass,
                unfocusedContainerColor = BackgroundDarkSecondary.copy(alpha = 0.7f),
                focusedBorderColor = AccentCyan,
                unfocusedBorderColor = SilverBorder,
                focusedTextColor = TextWhite,
                unfocusedTextColor = TextWhite,
                errorBorderColor = ErrorRed
            ),
            modifier = Modifier.fillMaxWidth()
        )
        if (isError && errorMessage != null) {
            Text(
                text = errorMessage,
                color = ErrorRed,
                fontSize = 11.sp,
                modifier = Modifier.padding(start = 6.dp, top = 4.dp)
            )
        }
    }
}

@Composable
fun TopBarHeader(
    title: String,
    subtitle: String? = null,
    walletBalancePaise: Long = 0L,
    onWalletClick: () -> Unit = {},
    onNotificationClick: () -> Unit = {},
    onAdminClick: () -> Unit = {},
    showAdminButton: Boolean = false
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .padding(horizontal = 20.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = title,
                    color = TextWhite,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 22.sp
                )
                Spacer(modifier = Modifier.width(6.dp))
                LiquidPulseDot()
            }
            if (subtitle != null) {
                Text(
                    text = subtitle,
                    color = TextMuted,
                    fontSize = 12.sp
                )
            }
        }

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Sleek liquid dynamic capsule for wallet balance
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(22.dp))
                    .background(
                        Brush.horizontalGradient(
                            listOf(
                                PrimaryBlue.copy(alpha = 0.25f),
                                AccentCyan.copy(alpha = 0.15f)
                            )
                        )
                    )
                    .border(
                        1.dp,
                        Brush.linearGradient(
                            listOf(AccentCyan.copy(alpha = 0.6f), Color.Transparent)
                        ),
                        RoundedCornerShape(22.dp)
                    )
                    .clickable { onWalletClick() }
                    .padding(horizontal = 12.dp, vertical = 7.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Filled.AccountBalanceWallet,
                        contentDescription = "Wallet",
                        tint = AccentCyan,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = CurrencyUtils.formatPaise(walletBalancePaise),
                        color = TextWhite,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }
            }

            if (showAdminButton) {
                IconButton(
                    onClick = onAdminClick,
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(Color(0x33FFB800))
                        .border(1.dp, CrownGold.copy(alpha = 0.5f), CircleShape)
                ) {
                    Icon(
                        Icons.Filled.AdminPanelSettings,
                        contentDescription = "Admin Panel",
                        tint = CrownGold,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun StatCard(
    title: String,
    value: String,
    subtitle: String,
    icon: ImageVector,
    iconTint: Color = AccentCyan,
    modifier: Modifier = Modifier
) {
    GlassCard(modifier = modifier) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(title, color = TextMuted, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(iconTint.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(icon, contentDescription = null, tint = iconTint, modifier = Modifier.size(18.dp))
                }
            }
            Spacer(modifier = Modifier.height(10.dp))
            Text(value, color = TextWhite, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
            Spacer(modifier = Modifier.height(2.dp))
            Text(subtitle, color = TextDim, fontSize = 11.sp)
        }
    }
}

@Composable
fun GlowingPillButton(
    text: String,
    onClick: () -> Unit,
    icon: ImageVector? = null,
    active: Boolean = false,
    modifier: Modifier = Modifier
) {
    val bgBrush = if (active) {
        Brush.horizontalGradient(listOf(PrimaryBlue, AccentCyan))
    } else {
        Brush.verticalGradient(listOf(Color(0x330B1736), Color(0x1A050B18)))
    }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(20.dp))
            .background(bgBrush)
            .border(
                1.dp,
                if (active) Brush.linearGradient(listOf(Color.White, Color.Transparent)) else SolidColor(SilverBorder),
                RoundedCornerShape(20.dp)
            )
            .clickable { onClick() }
            .padding(horizontal = 14.dp, vertical = 7.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (icon != null) {
                Icon(
                    icon,
                    contentDescription = null,
                    tint = if (active) BackgroundDark else TextWhite,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
            }
            Text(
                text = text,
                color = if (active) BackgroundDark else TextWhite,
                fontWeight = if (active) FontWeight.Bold else FontWeight.Medium,
                fontSize = 12.sp
            )
        }
    }
}

@Composable
fun StatusBadge(
    status: String,
    modifier: Modifier = Modifier
) {
    val (color, label) = when (status.uppercase()) {
        "COMPLETED", "APPROVED" -> Pair(SuccessGreen, status)
        "PROCESSING" -> Pair(PrimaryBlue, status)
        "PENDING" -> Pair(WarningAmber, status)
        "CANCELLED", "REJECTED" -> Pair(ErrorRed, status)
        else -> Pair(TextMuted, status)
    }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(color.copy(alpha = 0.15f))
            .border(1.dp, color.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Text(
            text = label,
            color = color,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun PlatformIconBadge(
    platform: String,
    modifier: Modifier = Modifier
) {
    val (color, initial) = when (platform.lowercase()) {
        "instagram" -> Pair(InstagramGradient[0], "IG")
        "youtube" -> Pair(YouTubeRed, "YT")
        "facebook" -> Pair(FacebookBlue, "FB")
        "telegram" -> Pair(TelegramCyan, "TG")
        else -> Pair(AccentCyan, platform.take(2).uppercase())
    }

    Box(
        modifier = modifier
            .size(32.dp)
            .clip(CircleShape)
            .background(color.copy(alpha = 0.2f))
            .border(1.dp, color.copy(alpha = 0.5f), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = initial,
            color = Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp
        )
    }
}
