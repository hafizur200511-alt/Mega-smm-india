package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val MegaSmmColorScheme = darkColorScheme(
    primary = PrimaryBlue,
    onPrimary = TextWhite,
    primaryContainer = SecondaryBlue,
    onPrimaryContainer = TextWhite,
    secondary = AccentCyan,
    onSecondary = BackgroundDark,
    background = BackgroundDark,
    onBackground = TextWhite,
    surface = CardBackground,
    onSurface = TextWhite,
    surfaceVariant = BackgroundDarkSecondary,
    onSurfaceVariant = TextMuted,
    outline = SilverBorder,
    error = ErrorRed,
    onError = TextWhite
)

@Composable
fun MyApplicationTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = MegaSmmColorScheme,
        typography = Typography,
        content = content
    )
}
