package com.example.ui.screens

import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.CurrencyRupee
import androidx.compose.material.icons.filled.Numbers
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.CurrencyUtils
import com.example.data.FirebaseService
import com.example.data.QrCodeGenerator
import com.example.model.PaymentRequest
import com.example.model.UpiSettings
import com.example.model.UserProfile
import com.example.ui.components.GlassButton
import com.example.ui.components.GlassCard
import com.example.ui.components.GlassTextField
import com.example.ui.components.GlowingPillButton
import com.example.ui.components.LiquidPulseDot
import com.example.ui.components.StatusBadge
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.CardBackgroundGlass
import com.example.ui.theme.PrimaryBlue
import com.example.ui.theme.SilverBorder
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextDim
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun WalletScreen(
    userProfile: UserProfile?,
    upiSettings: UpiSettings,
    paymentRequests: List<PaymentRequest>,
    onPaymentSubmitted: () -> Unit
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    val scope = rememberCoroutineScope()

    var amountInput by remember { mutableStateOf("100") }
    var utrInput by remember { mutableStateOf("") }
    var isSubmitting by remember { mutableStateOf(false) }

    val presetAmounts = listOf("50", "100", "250", "500", "1000", "2000")
    val amountPaise = (amountInput.toDoubleOrNull()?.let { (it * 100).toLong() }) ?: 10000L

    val upiUri = remember(amountPaise, upiSettings) {
        QrCodeGenerator.buildUpiUri(
            upiId = upiSettings.upiId,
            payeeName = upiSettings.payeeName,
            amountPaise = amountPaise,
            transactionNote = "MEGA SMM Add Funds - ${userProfile?.email ?: ""}"
        )
    }

    val qrBitmap: Bitmap? = remember(upiUri) {
        QrCodeGenerator.generateQrBitmap(upiUri, size = 512)
    }

    val dateFormat = remember { SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Transparent)
            .padding(bottom = 90.dp)
    ) {
        // Top Header
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(horizontal = 20.dp, vertical = 14.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "Wallet & UPI Balance",
                        color = TextWhite,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 24.sp
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    LiquidPulseDot(color = SuccessGreen)
                }
                Text(
                    text = "Fast automated & manual verification for Indian UPI apps",
                    color = TextMuted,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(top = 2.dp)
                )
            }
        }

        // Current Balance Card
        item {
            Box(modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)) {
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp)
                    ) {
                        Text(
                            text = "CURRENT BALANCE",
                            color = TextMuted,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = CurrencyUtils.formatPaise(userProfile?.walletBalancePaise ?: 0L),
                            color = TextWhite,
                            fontSize = 32.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Instant deduction upon launching social media orders",
                            color = TextDim,
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }

        // Add Funds via UPI Section
        item {
            Box(modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)) {
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "Add Funds via UPI (Paytm / PhonePe / GPay)",
                            color = TextWhite,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        // Preset chips
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(presetAmounts) { amt ->
                                GlowingPillButton(
                                    text = "₹$amt",
                                    active = amountInput == amt,
                                    onClick = { amountInput = amt }
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        GlassTextField(
                            value = amountInput,
                            onValueChange = { amountInput = it.filter { c -> c.isDigit() } },
                            label = "Recharge Amount (INR ₹)",
                            placeholder = "100",
                            leadingIcon = Icons.Filled.CurrencyRupee,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(18.dp))

                        // Display QR Code
                        if (qrBitmap != null) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(20.dp))
                                    .background(Color.White)
                                    .padding(12.dp)
                            ) {
                                Image(
                                    bitmap = qrBitmap.asImageBitmap(),
                                    contentDescription = "Scan UPI QR Code",
                                    modifier = Modifier.size(190.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Copy UPI ID Pill
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(16.dp))
                                .background(Color(0x33000000))
                                .border(1.dp, SilverBorder, RoundedCornerShape(16.dp))
                                .clickable {
                                    clipboardManager.setText(AnnotatedString(upiSettings.upiId))
                                    Toast.makeText(context, "UPI ID copied: ${upiSettings.upiId}", Toast.LENGTH_SHORT).show()
                                }
                                .padding(horizontal = 14.dp, vertical = 8.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "UPI ID: ${upiSettings.upiId}",
                                    color = AccentCyan,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Icon(
                                    Icons.Filled.ContentCopy,
                                    contentDescription = "Copy",
                                    tint = AccentCyan,
                                    modifier = Modifier.size(14.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Launch UPI App Button
                        GlassButton(
                            text = "Open UPI App Directly",
                            onClick = {
                                try {
                                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(upiUri))
                                    context.startActivity(intent)
                                } catch (e: Exception) {
                                    Toast.makeText(context, "No UPI app found. Please scan QR or copy UPI ID.", Toast.LENGTH_LONG).show()
                                }
                            },
                            icon = Icons.Filled.Send,
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(20.dp))

                        // UTR Submission Form
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(16.dp))
                                .background(Color(0x2E0072FE))
                                .padding(16.dp)
                        ) {
                            Column {
                                Text(
                                    text = "Step 2: Enter 12-Digit UTR / Transaction No.",
                                    color = TextWhite,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )
                                Text(
                                    text = "After sending payment from your UPI app, paste the UTR number below to credit your account.",
                                    color = TextMuted,
                                    fontSize = 11.sp,
                                    modifier = Modifier.padding(top = 2.dp, bottom = 10.dp)
                                )

                                GlassTextField(
                                    value = utrInput,
                                    onValueChange = { utrInput = it.trim() },
                                    label = "",
                                    placeholder = "e.g. 428901234567",
                                    leadingIcon = Icons.Filled.Numbers,
                                    modifier = Modifier.fillMaxWidth()
                                )

                                Spacer(modifier = Modifier.height(12.dp))

                                GlassButton(
                                    text = "Submit UTR for Verification",
                                    onClick = {
                                        if (utrInput.length < 6) {
                                            Toast.makeText(context, "Please enter valid transaction UTR reference", Toast.LENGTH_SHORT).show()
                                            return@GlassButton
                                        }

                                        isSubmitting = true
                                        scope.launch {
                                            val uid = userProfile?.uid ?: FirebaseService.currentUser?.uid ?: ""
                                            if (uid.isBlank()) {
                                                Toast.makeText(context, "Please sign in to submit a deposit request", Toast.LENGTH_SHORT).show()
                                                isSubmitting = false
                                                return@launch
                                            }
                                            val email = userProfile?.email ?: FirebaseService.currentUser?.email ?: ""
                                            val res = FirebaseService.submitPaymentRequest(
                                                userId = uid,
                                                userEmail = email,
                                                amountPaise = amountPaise,
                                                upiIdUsed = upiSettings.upiId,
                                                transactionReference = utrInput
                                            )
                                            isSubmitting = false
                                            if (res.isSuccess) {
                                                Toast.makeText(context, "Payment request submitted! Admin will verify shortly.", Toast.LENGTH_LONG).show()
                                                utrInput = ""
                                                onPaymentSubmitted()
                                            } else {
                                                Toast.makeText(context, "Submission failed, try again", Toast.LENGTH_SHORT).show()
                                            }
                                        }
                                    },
                                    isLoading = isSubmitting,
                                    enabled = !isSubmitting,
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }
                    }
                }
            }
        }

        // Past payment requests history
        item {
            Text(
                text = "Deposit & Verification History",
                color = TextWhite,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 16.dp, bottom = 8.dp)
            )
        }

        if (paymentRequests.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(30.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "No previous UPI deposits recorded",
                        color = TextMuted,
                        fontSize = 13.sp
                    )
                }
            }
        } else {
            items(paymentRequests) { req ->
                Box(modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp)) {
                    GlassCard(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = CurrencyUtils.formatPaise(req.amountPaise),
                                    color = TextWhite,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp
                                )
                                Text(
                                    text = "UTR: ${req.transactionReference}",
                                    color = TextMuted,
                                    fontSize = 11.sp
                                )
                                Text(
                                    text = dateFormat.format(Date(req.createdAt)),
                                    color = TextDim,
                                    fontSize = 10.sp
                                )
                            }
                            StatusBadge(status = req.status)
                        }
                    }
                }
            }
        }
    }
}
