package com.example.ui.screens.admin

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.CurrencyUtils
import com.example.data.FirebaseService
import com.example.model.Announcement
import com.example.model.Order
import com.example.model.PaymentRequest
import com.example.model.ServiceItem
import com.example.model.UpiSettings
import com.example.model.UserProfile
import com.example.ui.components.GlassButton
import com.example.ui.components.GlassCard
import com.example.ui.components.GlassTextField
import com.example.ui.components.GlowingPillButton
import com.example.ui.components.PlatformIconBadge
import com.example.ui.components.StatCard
import com.example.ui.components.StatusBadge
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.CardBackgroundGlass
import com.example.ui.theme.CrownGold
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.PrimaryBlue
import com.example.ui.theme.SilverBorder
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextDim
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite
import com.example.ui.theme.WarningAmber
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun AdminPanelScreen(
    userProfile: UserProfile?,
    onNavigateBack: () -> Unit
) {
    BackHandler { onNavigateBack() }
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    if (userProfile?.isAdmin != true) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Transparent)
                .padding(24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(Icons.Filled.AdminPanelSettings, contentDescription = null, tint = ErrorRed, modifier = Modifier.size(54.dp))
            Spacer(modifier = Modifier.height(14.dp))
            Text("Access Restricted", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 20.sp)
            Text("Only authorized admin emails can access this suite.", color = TextMuted, fontSize = 13.sp)
            Spacer(modifier = Modifier.height(20.dp))
            GlassButton(text = "Go Back", onClick = onNavigateBack)
        }
        return
    }

    var currentTab by remember { mutableStateOf(AdminTab.DASHBOARD) }

    val services by FirebaseService.observeServices().collectAsState(initial = FirebaseService.DEFAULT_SERVICES)
    val orders by FirebaseService.observeAllOrders().collectAsState(initial = emptyList())
    val paymentRequests by FirebaseService.observeAllPaymentRequests().collectAsState(initial = emptyList())
    val upiSettings by FirebaseService.observeUpiSettings().collectAsState(initial = UpiSettings())
    val users by FirebaseService.observeAllUsers().collectAsState(initial = emptyList())
    val announcements by FirebaseService.observeAnnouncements().collectAsState(initial = emptyList())

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Transparent)
    ) {
        // Admin Top Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onNavigateBack) {
                Icon(Icons.Filled.ArrowBack, contentDescription = "Back", tint = PrimaryBlue)
            }
            Spacer(modifier = Modifier.width(6.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text("Admin Operations Hub", color = TextWhite, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                Text("Logged in as ${userProfile.email}", color = CrownGold, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }

        // Horizontal Category Tabs
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.padding(bottom = 12.dp)
        ) {
            items(AdminTab.entries) { tab ->
                val isSelected = tab == currentTab
                GlowingPillButton(
                    text = tab.title,
                    icon = tab.icon,
                    active = isSelected,
                    onClick = { currentTab = tab }
                )
            }
        }

        // Tab Content
        Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
            when (currentTab) {
                AdminTab.DASHBOARD -> AdminDashboardView(services, orders, paymentRequests, users)
                AdminTab.SERVICES -> AdminServicesView(services)
                AdminTab.ORDERS -> AdminOrdersView(orders)
                AdminTab.PAYMENTS -> AdminPaymentsView(paymentRequests, userProfile.uid)
                AdminTab.UPI_CONFIG -> AdminUpiConfigView(upiSettings)
                AdminTab.USERS -> AdminUsersView(users)
                AdminTab.BROADCASTS -> AdminAnnouncementsView(announcements)
            }
        }
    }
}

@Composable
private fun AdminDashboardView(
    services: List<ServiceItem>,
    orders: List<Order>,
    paymentRequests: List<PaymentRequest>,
    users: List<UserProfile>
) {
    val pendingPayments = paymentRequests.count { it.status == "PENDING" }
    val totalRevenuePaise = orders.filter { it.status == "COMPLETED" }.sumOf { it.totalAmountPaise }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text("Platform Metrics", color = TextWhite, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                StatCard(
                    title = "TOTAL ORDERS",
                    value = orders.size.toString(),
                    subtitle = "Across all platforms",
                    icon = Icons.Filled.ShoppingBag,
                    modifier = Modifier.weight(1f)
                )
                StatCard(
                    title = "PENDING UPI",
                    value = pendingPayments.toString(),
                    subtitle = "Awaiting verification",
                    icon = Icons.Filled.Payment,
                    iconTint = if (pendingPayments > 0) WarningAmber else AccentCyan,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                StatCard(
                    title = "REVENUE PROCESSED",
                    value = CurrencyUtils.formatPaise(totalRevenuePaise),
                    subtitle = "Completed orders",
                    icon = Icons.Filled.QrCode,
                    iconTint = SuccessGreen,
                    modifier = Modifier.weight(1f)
                )
                StatCard(
                    title = "REGISTERED USERS",
                    value = users.size.coerceAtLeast(1).toString(),
                    subtitle = "Client accounts",
                    icon = Icons.Filled.Group,
                    iconTint = PrimaryBlue,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item {
            Spacer(modifier = Modifier.height(10.dp))
            Text("Quick Administrative Actions", color = TextWhite, fontSize = 15.sp, fontWeight = FontWeight.Bold)
        }

        item {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Seed / Restore Default SMM Packages", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text("Re-populates 7 essential services if the catalog was cleared.", color = TextMuted, fontSize = 11.sp)
                    Spacer(modifier = Modifier.height(10.dp))
                    val scope = rememberCoroutineScope()
                    val context = LocalContext.current
                    GlassButton(
                        text = "Seed Default Services",
                        onClick = {
                            scope.launch {
                                FirebaseService.seedDefaultServicesIfEmpty()
                                Toast.makeText(context, "Default services seeded!", Toast.LENGTH_SHORT).show()
                            }
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun AdminServicesView(services: List<ServiceItem>) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var editingService by remember { mutableStateOf<ServiceItem?>(null) }
    var serviceToDelete by remember { mutableStateOf<ServiceItem?>(null) }
    var isCreatingNew by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Manage Services (${services.size})", color = TextWhite, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(14.dp))
                        .background(PrimaryBlue)
                        .clickable {
                            editingService = ServiceItem(id = "SRV-" + System.currentTimeMillis().toString().takeLast(6))
                            isCreatingNew = true
                        }
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Add, contentDescription = null, tint = TextWhite, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Add New", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }
        }

        items(services) { service ->
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            PlatformIconBadge(platform = service.platform)
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(service.name, color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text("${service.platform} • ${service.category}", color = AccentCyan, fontSize = 11.sp)
                            }
                        }
                        Switch(
                            checked = service.isActive,
                            onCheckedChange = {
                                scope.launch {
                                    FirebaseService.toggleServiceActive(service.id, service.isActive)
                                }
                            },
                            colors = SwitchDefaults.colors(checkedThumbColor = AccentCyan)
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Price: ${CurrencyUtils.formatPaise(service.pricePerThousandPaise)} / 1K", color = SuccessGreen, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            IconButton(
                                onClick = {
                                    editingService = service
                                    isCreatingNew = false
                                },
                                modifier = Modifier.size(28.dp)
                            ) {
                                Icon(Icons.Filled.Edit, contentDescription = "Edit", tint = PrimaryBlue, modifier = Modifier.size(18.dp))
                            }
                            IconButton(
                                onClick = { serviceToDelete = service },
                                modifier = Modifier.size(28.dp)
                            ) {
                                Icon(Icons.Filled.Delete, contentDescription = "Delete", tint = ErrorRed, modifier = Modifier.size(18.dp))
                            }
                        }
                    }
                }
            }
        }
    }

    // Delete confirmation dialog
    if (serviceToDelete != null) {
        val toDelete = serviceToDelete!!
        AlertDialog(
            onDismissRequest = { serviceToDelete = null },
            title = { Text("Delete Service?", color = TextWhite, fontWeight = FontWeight.Bold) },
            text = { Text("Are you sure you want to remove '${toDelete.name}'? Existing completed orders will not be affected.", color = TextMuted) },
            confirmButton = {
                TextButton(
                    onClick = {
                        scope.launch {
                            FirebaseService.deleteService(toDelete.id)
                            serviceToDelete = null
                        }
                    }
                ) {
                    Text("Delete", color = ErrorRed, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { serviceToDelete = null }) {
                    Text("Cancel", color = TextMuted)
                }
            },
            containerColor = Color(0xFF0F172A)
        )
    }

    // Edit/Create dialog
    if (editingService != null) {
        AdminServiceEditDialog(
            service = editingService!!,
            isNew = isCreatingNew,
            onDismiss = { editingService = null },
            onSave = { updated ->
                scope.launch {
                    FirebaseService.saveService(updated)
                    editingService = null
                    Toast.makeText(context, "Service saved!", Toast.LENGTH_SHORT).show()
                }
            }
        )
    }
}

@Composable
private fun AdminServiceEditDialog(
    service: ServiceItem,
    isNew: Boolean,
    onDismiss: () -> Unit,
    onSave: (ServiceItem) -> Unit
) {
    var name by remember { mutableStateOf(service.name) }
    var platform by remember { mutableStateOf(service.platform) }
    var category by remember { mutableStateOf(service.category) }
    var priceText by remember { mutableStateOf((service.pricePerThousandPaise / 100.0).toString()) }
    var minQtyText by remember { mutableStateOf(service.minQuantity.toString()) }
    var maxQtyText by remember { mutableStateOf(service.maxQuantity.toString()) }
    var description by remember { mutableStateOf(service.description) }
    var deliveryInfo by remember { mutableStateOf(service.deliveryInfo) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(if (isNew) "Add Service Package" else "Edit Service", color = TextWhite, fontWeight = FontWeight.Bold)
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                GlassTextField(value = name, onValueChange = { name = it }, label = "Service Name")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GlassTextField(value = platform, onValueChange = { platform = it }, label = "Platform", modifier = Modifier.weight(1f))
                    GlassTextField(value = category, onValueChange = { category = it }, label = "Category", modifier = Modifier.weight(1f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GlassTextField(value = priceText, onValueChange = { priceText = it }, label = "Price (₹ / 1K)", modifier = Modifier.weight(1f))
                    GlassTextField(value = minQtyText, onValueChange = { minQtyText = it }, label = "Min Qty", modifier = Modifier.weight(1f))
                }
                GlassTextField(value = deliveryInfo, onValueChange = { deliveryInfo = it }, label = "Delivery Info Note")
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val pricePaise = (priceText.toDoubleOrNull()?.let { (it * 100).toLong() }) ?: 1000L
                    val minQty = minQtyText.toIntOrNull() ?: 50
                    val maxQty = maxQtyText.toIntOrNull() ?: 100000
                    onSave(
                        service.copy(
                            name = name,
                            platform = platform,
                            category = category,
                            pricePerThousandPaise = pricePaise,
                            minQuantity = minQty,
                            maxQuantity = maxQty,
                            description = description,
                            deliveryInfo = deliveryInfo
                        )
                    )
                },
                colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue)
            ) {
                Text("Save", color = TextWhite)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Close", color = TextMuted)
            }
        },
        containerColor = Color(0xFF0F172A)
    )
}

@Composable
private fun AdminOrdersView(orders: List<Order>) {
    val scope = rememberCoroutineScope()
    var selectedOrder by remember { mutableStateOf<Order?>(null) }
    val dateFormat = remember { SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text("Manage Orders (${orders.size})", color = TextWhite, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        }

        items(orders) { order ->
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("#${order.id}", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        StatusBadge(status = order.status)
                    }
                    Text("User: ${order.userEmail}", color = TextDim, fontSize = 11.sp)
                    Text(order.serviceName, color = AccentCyan, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    Text("Target: ${order.targetUrl}", color = TextMuted, fontSize = 11.sp, maxLines = 1)
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Qty: ${order.quantity} | Total: ${CurrencyUtils.formatPaise(order.totalAmountPaise)}", color = TextWhite, fontSize = 12.sp)
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(PrimaryBlue.copy(alpha = 0.25f))
                                .clickable { selectedOrder = order }
                                .padding(horizontal = 10.dp, vertical = 5.dp)
                        ) {
                            Text("Update Status", color = TextWhite, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }

    if (selectedOrder != null) {
        val current = selectedOrder!!
        var chosenStatus by remember { mutableStateOf(current.status) }
        val statuses = listOf("PENDING", "PROCESSING", "COMPLETED", "CANCELLED")

        AlertDialog(
            onDismissRequest = { selectedOrder = null },
            title = { Text("Update Order #${current.id}", color = TextWhite) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    statuses.forEach { st ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (chosenStatus == st) PrimaryBlue.copy(alpha = 0.3f) else Color.Transparent)
                                .clickable { chosenStatus = st }
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            StatusBadge(status = st)
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(st, color = TextWhite, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        scope.launch {
                            FirebaseService.updateOrderStatus(current.id, chosenStatus)
                            selectedOrder = null
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue)
                ) {
                    Text("Apply", color = TextWhite)
                }
            },
            dismissButton = {
                TextButton(onClick = { selectedOrder = null }) { Text("Cancel", color = TextMuted) }
            },
            containerColor = Color(0xFF0F172A)
        )
    }
}

@Composable
private fun AdminPaymentsView(
    paymentRequests: List<PaymentRequest>,
    adminId: String
) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    var rejectingReq by remember { mutableStateOf<PaymentRequest?>(null) }
    var rejectionReason by remember { mutableStateOf("Invalid UTR Reference") }

    val pending = paymentRequests.filter { it.status == "PENDING" }
    val reviewed = paymentRequests.filter { it.status != "PENDING" }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text("Pending UPI Verification (${pending.size})", color = WarningAmber, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Text("Verify that the UTR appears in your bank/UPI app records before approving.", color = TextMuted, fontSize = 11.sp)
        }

        if (pending.isEmpty()) {
            item {
                Box(modifier = Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
                    Text("No pending payment verification requests 🎉", color = TextMuted, fontSize = 13.sp)
                }
            }
        } else {
            items(pending) { req ->
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(CurrencyUtils.formatPaise(req.amountPaise), color = TextWhite, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
                            StatusBadge(status = req.status)
                        }
                        Text("User: ${req.userEmail}", color = TextMuted, fontSize = 12.sp)
                        Text("UTR / Ref: ${req.transactionReference}", color = AccentCyan, fontSize = 13.sp, fontWeight = FontWeight.Bold)

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = {
                                    scope.launch {
                                        FirebaseService.approvePaymentRequest(req.id, adminId)
                                        Toast.makeText(context, "Payment approved & credited!", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Approve & Credit", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                            OutlinedButton(
                                onClick = { rejectingReq = req },
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = ErrorRed),
                                modifier = Modifier.weight(0.7f)
                            ) {
                                Text("Reject", color = ErrorRed, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(10.dp))
            Text("Past Processed Requests (${reviewed.size})", color = TextWhite, fontSize = 14.sp, fontWeight = FontWeight.Bold)
        }

        items(reviewed) { req ->
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(CurrencyUtils.formatPaise(req.amountPaise), color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text("UTR: ${req.transactionReference}", color = TextMuted, fontSize = 11.sp)
                        Text("User: ${req.userEmail}", color = TextDim, fontSize = 10.sp)
                    }
                    StatusBadge(status = req.status)
                }
            }
        }
    }

    if (rejectingReq != null) {
        val req = rejectingReq!!
        AlertDialog(
            onDismissRequest = { rejectingReq = null },
            title = { Text("Reject Payment Request", color = TextWhite, fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Text("Specify reason for rejecting ${CurrencyUtils.formatPaise(req.amountPaise)} (UTR: ${req.transactionReference}):", color = TextMuted, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    GlassTextField(
                        value = rejectionReason,
                        onValueChange = { rejectionReason = it },
                        label = "Rejection Reason"
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        scope.launch {
                            FirebaseService.rejectPaymentRequest(req.id, rejectionReason)
                            rejectingReq = null
                            Toast.makeText(context, "Payment marked as rejected", Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ErrorRed)
                ) {
                    Text("Confirm Rejection", color = TextWhite, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { rejectingReq = null }) { Text("Cancel", color = TextMuted) }
            },
            containerColor = Color(0xFF0F172A)
        )
    }
}

@Composable
private fun AdminUpiConfigView(settings: UpiSettings) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    var upiId by remember(settings) { mutableStateOf(settings.upiId) }
    var payeeName by remember(settings) { mutableStateOf(settings.payeeName) }
    var minRecharge by remember(settings) { mutableStateOf((settings.minRechargePaise / 100).toString()) }
    var maxRecharge by remember(settings) { mutableStateOf((settings.maxRechargePaise / 100).toString()) }
    var instructions by remember(settings) { mutableStateOf(settings.instructions) }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("UPI QR & Payment Settings", color = TextWhite, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Text("Updates take effect in real-time across all user apps without requiring a new APK build.", color = TextMuted, fontSize = 11.sp)
        }

        item {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    GlassTextField(value = upiId, onValueChange = { upiId = it.trim() }, label = "Active UPI ID (e.g. user@paytm)")
                    GlassTextField(value = payeeName, onValueChange = { payeeName = it }, label = "Payee Merchant / Business Name")
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        GlassTextField(value = minRecharge, onValueChange = { minRecharge = it }, label = "Min Deposit (₹)", modifier = Modifier.weight(1f))
                        GlassTextField(value = maxRecharge, onValueChange = { maxRecharge = it }, label = "Max Deposit (₹)", modifier = Modifier.weight(1f))
                    }
                    GlassTextField(value = instructions, onValueChange = { instructions = it }, label = "Payment Instructions")

                    Spacer(modifier = Modifier.height(10.dp))

                    GlassButton(
                        text = "Save UPI Configuration",
                        onClick = {
                            val minPaise = (minRecharge.toLongOrNull() ?: 10L) * 100L
                            val maxPaise = (maxRecharge.toLongOrNull() ?: 50000L) * 100L
                            scope.launch {
                                FirebaseService.saveUpiSettings(
                                    settings.copy(
                                        upiId = upiId,
                                        payeeName = payeeName,
                                        minRechargePaise = minPaise,
                                        maxRechargePaise = maxPaise,
                                        instructions = instructions,
                                        updatedAt = System.currentTimeMillis()
                                    )
                                )
                                Toast.makeText(context, "UPI settings updated successfully!", Toast.LENGTH_SHORT).show()
                            }
                        },
                        icon = Icons.Filled.Save,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }

        item {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Official Customer Support", color = TextWhite, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    Text("Instagram DM: @megasmmindia", color = AccentCyan, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}

@Composable
private fun AdminAnnouncementsView(announcements: List<Announcement>) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    var title by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text("Broadcast Announcements", color = TextWhite, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Text("Post news, promos, or server maintenance alerts to all users.", color = TextMuted, fontSize = 11.sp)
        }

        item {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    GlassTextField(value = title, onValueChange = { title = it }, label = "Notice Title")
                    GlassTextField(value = message, onValueChange = { message = it }, label = "Notice Details")
                    GlassButton(
                        text = "Broadcast to Users",
                        onClick = {
                            if (title.isBlank()) return@GlassButton
                            scope.launch {
                                FirebaseService.createAnnouncement(title, message)
                                title = ""
                                message = ""
                                Toast.makeText(context, "Announcement broadcasted!", Toast.LENGTH_SHORT).show()
                            }
                        },
                        icon = Icons.Filled.Add,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }

        items(announcements) { ann ->
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(ann.title, color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text(ann.message, color = TextMuted, fontSize = 11.sp)
                    }
                    IconButton(
                        onClick = {
                            scope.launch {
                                FirebaseService.deleteAnnouncement(ann.id)
                            }
                        }
                    ) {
                        Icon(Icons.Filled.Delete, contentDescription = "Delete", tint = ErrorRed, modifier = Modifier.size(18.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun AdminUsersView(users: List<UserProfile>) {
    val scope = rememberCoroutineScope()

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text("Registered Users (${users.size})", color = TextWhite, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        }

        items(users) { u ->
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(u.displayName.ifBlank { "User" }, color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text(u.email, color = TextMuted, fontSize = 11.sp)
                        Text("Balance: ${CurrencyUtils.formatPaise(u.walletBalancePaise)}", color = AccentCyan, fontSize = 11.sp)
                    }
                    if (u.isAdmin) {
                        Text("ADMIN", color = CrownGold, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    } else {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (u.isSuspended) ErrorRed.copy(alpha = 0.2f) else SuccessGreen.copy(alpha = 0.2f))
                                .clickable {
                                    scope.launch {
                                        FirebaseService.toggleUserSuspension(u.uid, u.isSuspended)
                                    }
                                }
                                .padding(horizontal = 10.dp, vertical = 5.dp)
                        ) {
                            Text(
                                text = if (u.isSuspended) "Suspended" else "Active",
                                color = if (u.isSuspended) ErrorRed else SuccessGreen,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}
