package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.SupportAgent
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.CurrencyUtils
import com.example.data.FirebaseService
import com.example.model.UserProfile
import com.example.ui.components.GlassButton
import com.example.ui.components.GlassCard
import com.example.ui.components.LiquidPulseDot
import com.example.ui.components.StatCard
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.CrownGold
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.InstagramGradient
import com.example.ui.theme.LiquidGlassSpecularBorder
import com.example.ui.theme.PrimaryBlue
import com.example.ui.theme.SilverBorder
import com.example.ui.theme.TextDim
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite

@Composable
fun ProfileScreen(
    userProfile: UserProfile?,
    onSignOut: () -> Unit,
    onAdminClick: () -> Unit
) {
    val context = LocalContext.current

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Transparent)
            .padding(bottom = 90.dp)
    ) {
        // Screen Header
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(horizontal = 20.dp, vertical = 14.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "User Account",
                        color = TextWhite,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 24.sp
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    LiquidPulseDot()
                }
                Text(
                    text = "Manage your preferences, security & tier",
                    color = TextMuted,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(top = 2.dp)
                )
            }
        }

        // Profile Identity Card
        item {
            Box(modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)) {
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        // Avatar
                        Box(
                            modifier = Modifier
                                .size(72.dp)
                                .clip(CircleShape)
                                .background(Brush.linearGradient(listOf(PrimaryBlue, AccentCyan)))
                                .border(2.dp, LiquidGlassSpecularBorder, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = (userProfile?.displayName?.take(1) ?: "U").uppercase(),
                                color = Color.White,
                                fontSize = 28.sp,
                                fontWeight = FontWeight.ExtraBold
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = userProfile?.displayName ?: "Member",
                            color = TextWhite,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )

                        Text(
                            text = userProfile?.email ?: "",
                            color = TextMuted,
                            fontSize = 12.sp
                        )

                        if (userProfile?.isAdmin == true) {
                            Spacer(modifier = Modifier.height(10.dp))
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(Color(0x33FFB800))
                                    .border(1.dp, CrownGold.copy(alpha = 0.6f), RoundedCornerShape(14.dp))
                                    .padding(horizontal = 12.dp, vertical = 5.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        Icons.Filled.AdminPanelSettings,
                                        contentDescription = null,
                                        tint = CrownGold,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "SUPER ADMINISTRATOR",
                                        color = CrownGold,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Stats summary row
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                StatCard(
                    title = "WALLET BALANCE",
                    value = CurrencyUtils.formatPaise(userProfile?.walletBalancePaise ?: 0L),
                    subtitle = "Real-time credits",
                    icon = Icons.Filled.Shield,
                    iconTint = AccentCyan,
                    modifier = Modifier.weight(1f)
                )
                StatCard(
                    title = "TOTAL ORDERS",
                    value = (userProfile?.totalOrders ?: 0).toString(),
                    subtitle = "Lifetime orders",
                    icon = Icons.Filled.Person,
                    iconTint = PrimaryBlue,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Admin Panel Shortcut (if Admin)
        if (userProfile?.isAdmin == true) {
            item {
                Box(modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(20.dp))
                            .background(Color(0x33FFB800))
                            .border(1.dp, CrownGold.copy(alpha = 0.5f), RoundedCornerShape(20.dp))
                            .clickable { onAdminClick() }
                            .padding(18.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Filled.AdminPanelSettings, contentDescription = null, tint = CrownGold, modifier = Modifier.size(24.dp))
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text("Open Admin Control Panel", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    Text("Manage services, verify UPI deposits, post notices", color = TextMuted, fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }
            }
        }

        // Official Instagram Support (only Instagram as requested)
        item {
            Box(modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(20.dp))
                        .background(Color(0x2B833AB4))
                        .border(1.dp, Color(0x66FD1D1D), RoundedCornerShape(20.dp))
                        .clickable {
                            try {
                                val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://instagram.com/megasmmindia"))
                                context.startActivity(intent)
                            } catch (e: Exception) {
                                Toast.makeText(context, "Instagram: @megasmmindia", Toast.LENGTH_LONG).show()
                            }
                        }
                        .padding(16.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(Brush.linearGradient(InstagramGradient)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("IG", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text("Customer Support (Instagram)", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text("DM @megasmmindia for fast help", color = AccentCyan, fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        // Sign Out Button
        item {
            Box(modifier = Modifier.padding(horizontal = 20.dp, vertical = 12.dp)) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .clip(RoundedCornerShape(18.dp))
                        .background(Color(0x33EF4444))
                        .border(1.dp, ErrorRed.copy(alpha = 0.5f), RoundedCornerShape(18.dp))
                        .clickable {
                            FirebaseService.signOut(context) {
                                onSignOut()
                            }
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.ExitToApp, contentDescription = null, tint = ErrorRed, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Sign Out of Account", color = ErrorRed, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                }
            }
        }
    }
}
