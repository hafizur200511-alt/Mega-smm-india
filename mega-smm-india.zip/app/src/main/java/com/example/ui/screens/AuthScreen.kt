package com.example.ui.screens

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.util.Log
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import androidx.credentials.exceptions.NoCredentialException
import com.example.data.FirebaseService
import com.example.ui.components.GlassButton
import com.example.ui.components.GlassCard
import com.example.ui.components.GlassTextField
import com.example.ui.components.LiquidGlassBackground
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.BackgroundDark
import com.example.ui.theme.BackgroundDarkSecondary
import com.example.ui.theme.CardBackgroundGlass
import com.example.ui.theme.CrownGold
import com.example.ui.theme.EmeraldGlow
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.EmeraldGreenLight
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.InstagramGradient
import com.example.ui.theme.LiquidGlassSpecularBorder
import com.example.ui.theme.LuxuryCardBackground
import com.example.ui.theme.LuxuryEmeraldBorder
import com.example.ui.theme.LuxuryEmeraldButtonGradient
import com.example.ui.theme.LuxuryGold
import com.example.ui.theme.LuxuryGoldBorder
import com.example.ui.theme.SilverBorder
import com.example.ui.theme.TextDim
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.firebase.FirebaseNetworkException
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.FirebaseAuthInvalidUserException
import com.google.firebase.auth.FirebaseAuthUserCollisionException
import com.google.firebase.auth.FirebaseAuthWeakPasswordException
import com.google.firebase.auth.GoogleAuthProvider
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

@Composable
fun AuthScreen(
    onAuthSuccess: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val focusManager = LocalFocusManager.current

    var isSignUp by remember { mutableStateOf(false) }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var fullName by remember { mutableStateOf("") }

    var passwordVisible by remember { mutableStateOf(false) }
    var confirmPasswordVisible by remember { mutableStateOf(false) }

    var isLoading by remember { mutableStateOf(false) }
    var isGoogleLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var successMessage by remember { mutableStateOf<String?>(null) }

    var showForgotDialog by remember { mutableStateOf(false) }
    var forgotEmail by remember { mutableStateOf("") }
    var isSendingReset by remember { mutableStateOf(false) }

    var showTermsDialog by remember { mutableStateOf(false) }

    LiquidGlassBackground(
        modifier = Modifier.fillMaxSize()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 22.dp, vertical = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Spacer(modifier = Modifier.height(16.dp))

            // Luxury Brand Header
            Box(
                modifier = Modifier
                    .shadow(28.dp, RoundedCornerShape(32.dp), spotColor = EmeraldGlow)
                    .clip(RoundedCornerShape(32.dp))
                    .background(
                        Brush.linearGradient(
                            listOf(Color(0xFF042018), Color(0xFF064E3B), Color(0xFF021B14))
                        )
                    )
                    .border(1.5.dp, LuxuryEmeraldBorder, RoundedCornerShape(32.dp))
                    .size(80.dp),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Filled.WorkspacePremium,
                    contentDescription = "Brand Badge",
                    tint = LuxuryGold,
                    modifier = Modifier.size(46.dp)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "MEGA SMM INDIA",
                color = TextWhite,
                fontSize = 25.sp,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = 1.2.sp
            )

            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(top = 4.dp, bottom = 22.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(6.dp)
                        .clip(CircleShape)
                        .background(EmeraldGreen)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "India's Premier Social Growth Network",
                    color = TextMuted,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium
                )
            }

            // Error / Success Banner
            AnimatedVisibility(
                visible = errorMessage != null,
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0x33EF4444))
                        .border(1.dp, ErrorRed.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
                        .padding(14.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Error, contentDescription = null, tint = ErrorRed, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = errorMessage ?: "",
                            color = TextWhite,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }

            AnimatedVisibility(
                visible = successMessage != null,
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0x3310B981))
                        .border(1.dp, EmeraldGreen.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
                        .padding(14.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.CheckCircle, contentDescription = null, tint = EmeraldGreen, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = successMessage ?: "",
                            color = TextWhite,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }

            // Main Luxury Glass Card
            GlassCard(
                modifier = Modifier.fillMaxWidth(),
                backgroundColor = LuxuryCardBackground,
                borderBrush = LuxuryEmeraldBorder
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(22.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Sign In vs Sign Up Tabs
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(Color(0x66081424))
                            .border(1.dp, SilverBorder, RoundedCornerShape(16.dp))
                            .padding(4.dp)
                    ) {
                        Row(modifier = Modifier.fillMaxWidth()) {
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(
                                        if (!isSignUp) Brush.horizontalGradient(listOf(Color(0xFF065F46), EmeraldGreen))
                                        else SolidColor(Color.Transparent)
                                    )
                                    .clickable {
                                        isSignUp = false
                                        errorMessage = null
                                    }
                                    .padding(vertical = 10.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "Sign In",
                                    color = if (!isSignUp) TextWhite else TextMuted,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(
                                        if (isSignUp) Brush.horizontalGradient(listOf(Color(0xFF065F46), EmeraldGreen))
                                        else SolidColor(Color.Transparent)
                                    )
                                    .clickable {
                                        isSignUp = true
                                        errorMessage = null
                                    }
                                    .padding(vertical = 10.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "Create Account",
                                    color = if (isSignUp) TextWhite else TextMuted,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    // Optional Full Name for Sign Up
                    if (isSignUp) {
                        GlassTextField(
                            value = fullName,
                            onValueChange = { fullName = it },
                            label = "Full Name",
                            placeholder = "Enter your full name",
                            leadingIcon = Icons.Filled.Person,
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("name_input")
                        )
                        Spacer(modifier = Modifier.height(14.dp))
                    }

                    // Email Field
                    GlassTextField(
                        value = email,
                        onValueChange = {
                            email = it
                            errorMessage = null
                        },
                        label = "Email Address",
                        placeholder = "you@example.com",
                        leadingIcon = Icons.Filled.Email,
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Email,
                            imeAction = ImeAction.Next
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("email_input")
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Password Field
                    GlassTextField(
                        value = password,
                        onValueChange = {
                            password = it
                            errorMessage = null
                        },
                        label = "Password",
                        placeholder = "Minimum 6 characters",
                        leadingIcon = Icons.Filled.Lock,
                        trailingIcon = {
                            IconButton(onClick = { passwordVisible = !passwordVisible }) {
                                Icon(
                                    if (passwordVisible) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                                    contentDescription = "Toggle password visibility",
                                    tint = TextMuted,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        },
                        visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Password,
                            imeAction = if (isSignUp) ImeAction.Next else ImeAction.Done
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("password_input")
                    )

                    // Confirm Password Field for Sign Up
                    if (isSignUp) {
                        Spacer(modifier = Modifier.height(14.dp))
                        GlassTextField(
                            value = confirmPassword,
                            onValueChange = {
                                confirmPassword = it
                                errorMessage = null
                            },
                            label = "Confirm Password",
                            placeholder = "Re-enter your password",
                            leadingIcon = Icons.Filled.Lock,
                            trailingIcon = {
                                IconButton(onClick = { confirmPasswordVisible = !confirmPasswordVisible }) {
                                    Icon(
                                        if (confirmPasswordVisible) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                                        contentDescription = "Toggle confirm password visibility",
                                        tint = TextMuted,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            },
                            visualTransformation = if (confirmPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                            keyboardOptions = KeyboardOptions(
                                keyboardType = KeyboardType.Password,
                                imeAction = ImeAction.Done
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("confirm_password_input")
                        )
                    }

                    // Forgot Password Link for Sign In
                    if (!isSignUp) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 8.dp),
                            horizontalArrangement = Arrangement.End
                        ) {
                            Text(
                                text = "Forgot Password?",
                                color = LuxuryGold,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier
                                    .clickable {
                                        forgotEmail = email
                                        showForgotDialog = true
                                    }
                                    .padding(vertical = 4.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    // Primary Auth Action Button (Emerald Gradient)
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .shadow(16.dp, RoundedCornerShape(18.dp), spotColor = EmeraldGlow)
                            .clip(RoundedCornerShape(18.dp))
                            .background(LuxuryEmeraldButtonGradient)
                            .border(1.dp, LuxuryEmeraldBorder, RoundedCornerShape(18.dp))
                            .clickable(enabled = !isLoading && !isGoogleLoading) {
                                focusManager.clearFocus()
                                executeEmailAuth(
                                    isSignUp = isSignUp,
                                    email = email,
                                    password = password,
                                    confirmPassword = confirmPassword,
                                    fullName = fullName,
                                    coroutineScope = coroutineScope,
                                    onLoading = { isLoading = it },
                                    onError = { errorMessage = it },
                                    onSuccess = onAuthSuccess
                                )
                            }
                            .testTag("submit_auth_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        if (isLoading) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(22.dp),
                                color = TextWhite,
                                strokeWidth = 2.dp
                            )
                        } else {
                            Text(
                                text = if (isSignUp) "Create Mega SMM Account" else "Sign In Securely",
                                color = TextWhite,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    // Divider
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(modifier = Modifier.weight(1f).height(1.dp).background(Color(0x33CBD5E1)))
                        Text(
                            text = "  OR  ",
                            color = TextDim,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Box(modifier = Modifier.weight(1f).height(1.dp).background(Color(0x33CBD5E1)))
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    // Official Google Sign-In Button
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .shadow(12.dp, RoundedCornerShape(18.dp), spotColor = Color.White.copy(alpha = 0.15f))
                            .clip(RoundedCornerShape(18.dp))
                            .background(Color.White)
                            .border(1.dp, Color(0x33000000), RoundedCornerShape(18.dp))
                            .clickable(enabled = !isLoading && !isGoogleLoading) {
                                focusManager.clearFocus()
                                executeGoogleSignIn(
                                    context = context,
                                    coroutineScope = coroutineScope,
                                    onLoading = { isGoogleLoading = it },
                                    onError = { errorMessage = it },
                                    onSuccess = onAuthSuccess
                                )
                            }
                            .testTag("google_signin_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        if (isGoogleLoading) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(22.dp),
                                color = EmeraldGreen,
                                strokeWidth = 2.dp
                            )
                        } else {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                // Google G colored icon representation
                                Box(
                                    modifier = Modifier
                                        .size(24.dp)
                                        .clip(CircleShape)
                                        .background(Color(0xFFEA4335)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text("G", color = Color.White, fontWeight = FontWeight.Black, fontSize = 14.sp)
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = "Continue with Google",
                                    color = Color(0xFF1F2937),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Terms & Policy links
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = "By continuing, you agree to our ",
                            color = TextDim,
                            fontSize = 11.sp
                        )
                        Text(
                            text = "Terms & Privacy",
                            color = EmeraldGreenLight,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.clickable { showTermsDialog = true }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Exclusive Instagram Support (@megasmmindia)
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color(0x26833AB4))
                    .border(1.dp, Color(0x66FD1D1D), RoundedCornerShape(20.dp))
                    .clickable {
                        try {
                            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://instagram.com/megasmmindia"))
                            context.startActivity(intent)
                        } catch (e: Exception) {
                            Toast.makeText(context, "Official IG Support: @megasmmindia", Toast.LENGTH_LONG).show()
                        }
                    }
                    .padding(horizontal = 16.dp, vertical = 10.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(26.dp)
                            .clip(CircleShape)
                            .background(Brush.linearGradient(InstagramGradient)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("IG", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text("24/7 Official Support", color = TextWhite, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Text("@megasmmindia on Instagram", color = AccentCyan, fontSize = 11.sp)
                    }
                }
            }
        }
    }

    // Forgot Password Alert Dialog
    if (showForgotDialog) {
        AlertDialog(
            onDismissRequest = { if (!isSendingReset) showForgotDialog = false },
            title = {
                Text(
                    text = "Reset Your Password",
                    color = TextWhite,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
            },
            text = {
                Column {
                    Text(
                        text = "Enter your registered email address and we'll send you a password reset link.",
                        color = TextMuted,
                        fontSize = 13.sp,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )
                    GlassTextField(
                        value = forgotEmail,
                        onValueChange = { forgotEmail = it },
                        label = "Email Address",
                        placeholder = "you@example.com",
                        leadingIcon = Icons.Filled.Email,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        val clean = forgotEmail.trim()
                        if (clean.isBlank() || !android.util.Patterns.EMAIL_ADDRESS.matcher(clean).matches()) {
                            Toast.makeText(context, "Please enter a valid email.", Toast.LENGTH_SHORT).show()
                            return@TextButton
                        }
                        isSendingReset = true
                        coroutineScope.launch {
                            try {
                                FirebaseService.sendPasswordResetEmail(clean)
                                isSendingReset = false
                                showForgotDialog = false
                                successMessage = "Password reset email sent to $clean. Please check your inbox or spam folder."
                            } catch (e: Exception) {
                                isSendingReset = false
                                val msg = when (e) {
                                    is FirebaseAuthInvalidUserException -> "No account found with this email."
                                    is FirebaseNetworkException -> "Network error. Check your connection."
                                    else -> e.localizedMessage ?: "Failed to send reset link."
                                }
                                Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
                            }
                        }
                    },
                    enabled = !isSendingReset
                ) {
                    if (isSendingReset) {
                        CircularProgressIndicator(modifier = Modifier.size(16.dp), color = EmeraldGreen, strokeWidth = 2.dp)
                    } else {
                        Text("Send Reset Link", color = EmeraldGreen, fontWeight = FontWeight.Bold)
                    }
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showForgotDialog = false },
                    enabled = !isSendingReset
                ) {
                    Text("Cancel", color = TextMuted)
                }
            },
            containerColor = LuxuryCardBackground,
            shape = RoundedCornerShape(24.dp)
        )
    }

    // Terms of Service & Privacy Modal
    if (showTermsDialog) {
        AlertDialog(
            onDismissRequest = { showTermsDialog = false },
            title = {
                Text("Terms of Service & Privacy", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            },
            text = {
                Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                    Text(
                        text = "1. Account Security\nYour personal credentials and order telemetry are encrypted and managed directly via Firebase Security Rules. Only authenticated accounts can access services and order history.\n\n" +
                                "2. Wallet & UPI Transactions\nUPI deposits are verified against transaction reference IDs. Wallet balances are non-transferable and can be used across all services.\n\n" +
                                "3. Service Guarantee\nAll social media boosts, followers, and engagement services are fulfilled with high retention pacing. Lifetime non-drop warranty applies to tagged items.",
                        color = TextMuted,
                        fontSize = 12.sp,
                        lineHeight = 18.sp
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { showTermsDialog = false }) {
                    Text("Got It", color = EmeraldGreen, fontWeight = FontWeight.Bold)
                }
            },
            containerColor = LuxuryCardBackground,
            shape = RoundedCornerShape(24.dp)
        )
    }
}

// =============================================================================
// Helper Execution Functions
// =============================================================================

private fun executeEmailAuth(
    isSignUp: Boolean,
    email: String,
    password: String,
    confirmPassword: String,
    fullName: String,
    coroutineScope: CoroutineScope,
    onLoading: (Boolean) -> Unit,
    onError: (String) -> Unit,
    onSuccess: () -> Unit
) {
    val cleanEmail = email.trim()
    if (cleanEmail.isBlank()) {
        onError("Please enter your email address.")
        return
    }
    if (!android.util.Patterns.EMAIL_ADDRESS.matcher(cleanEmail).matches()) {
        onError("Please enter a valid email address.")
        return
    }
    if (password.length < 6) {
        onError("Password must be at least 6 characters.")
        return
    }
    if (isSignUp) {
        if (fullName.trim().isBlank()) {
            onError("Please enter your full name.")
            return
        }
        if (password != confirmPassword) {
            onError("Passwords do not match.")
            return
        }
    }

    onLoading(true)
    coroutineScope.launch {
        try {
            if (isSignUp) {
                FirebaseService.registerWithEmailAndPassword(cleanEmail, password, fullName)
            } else {
                FirebaseService.signInWithEmailAndPassword(cleanEmail, password)
            }
            onLoading(false)
            onSuccess()
        } catch (e: Exception) {
            onLoading(false)
            val msg = when (e) {
                is FirebaseAuthInvalidUserException -> "No account found with this email. Please register first."
                is FirebaseAuthInvalidCredentialsException -> "Incorrect email or password. Please try again."
                is FirebaseAuthUserCollisionException -> "An account with this email already exists. Please sign in instead."
                is FirebaseAuthWeakPasswordException -> "Password is too weak. Please use at least 6 characters."
                is FirebaseNetworkException -> "Network error. Please check your internet connection."
                else -> e.localizedMessage ?: "Authentication failed. Please check your credentials."
            }
            onError(msg)
        }
    }
}

private fun executeGoogleSignIn(
    context: Context,
    coroutineScope: CoroutineScope,
    onLoading: (Boolean) -> Unit,
    onError: (String) -> Unit,
    onSuccess: () -> Unit
) {
    val resId = context.resources.getIdentifier("default_web_client_id", "string", context.packageName)
    val clientId = if (resId != 0) context.getString(resId) else null

    if (clientId.isNullOrBlank()) {
        onError("Google Sign-In Web Client ID is not configured in google-services.json. Please sign in using Email & Password below.")
        return
    }

    onLoading(true)
    val credentialManager = CredentialManager.create(context)
    val signInOption = GetSignInWithGoogleOption.Builder(serverClientId = clientId).build()
    val request = GetCredentialRequest.Builder().addCredentialOption(signInOption).build()

    coroutineScope.launch {
        try {
            val result = credentialManager.getCredential(context as Activity, request)
            val credential = result.credential
            if (credential is CustomCredential && credential.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                val googleIdToken = GoogleIdTokenCredential.createFrom(credential.data).idToken
                val authCredential = GoogleAuthProvider.getCredential(googleIdToken, null)
                FirebaseService.signInWithCredential(authCredential)
                onLoading(false)
                onSuccess()
            } else {
                onLoading(false)
                onError("Unexpected credential response from Google.")
            }
        } catch (e: GetCredentialCancellationException) {
            Log.w("Auth", "User cancelled Google sign in flow")
            onLoading(false)
        } catch (e: NoCredentialException) {
            onLoading(false)
            onError("No Google account found on this device. Please sign in using Email & Password.")
        } catch (e: Exception) {
            onLoading(false)
            val msg = when {
                e is FirebaseNetworkException -> "Network error. Please check your internet connection."
                e.message?.contains("12500") == true -> "Google Sign-In failed (code 12500). Please check OAuth client credentials."
                else -> e.localizedMessage ?: "Google Sign-In failed. Please try again."
            }
            onError(msg)
        }
    }
}
