package com.example.ui.screens.admin

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.ui.graphics.vector.ImageVector

enum class AdminTab(
    val title: String,
    val icon: ImageVector
) {
    DASHBOARD("Overview", Icons.Filled.AdminPanelSettings),
    SERVICES("Services", Icons.Filled.ShoppingBag),
    ORDERS("Orders", Icons.Filled.ReceiptLong),
    PAYMENTS("Payments", Icons.Filled.Payment),
    UPI_CONFIG("UPI Setup", Icons.Filled.QrCode),
    USERS("Users", Icons.Filled.Group),
    BROADCASTS("Announce", Icons.Filled.Campaign)
}
