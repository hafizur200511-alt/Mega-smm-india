package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.SupportAgent
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.CurrencyUtils
import com.example.model.Announcement
import com.example.model.ServiceItem
import com.example.model.UserProfile
import com.example.ui.components.AppTab
import com.example.ui.components.GlassButton
import com.example.ui.components.GlassCard
import com.example.ui.components.GlowingPillButton
import com.example.ui.components.LiquidPulseDot
import com.example.ui.components.PlatformIconBadge
import com.example.ui.components.TopBarHeader
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.CardBackgroundGlass
import com.example.ui.theme.CrownGold
import com.example.ui.theme.InstagramGradient
import com.example.ui.theme.LiquidGlassSpecularBorder
import com.example.ui.theme.PrimaryBlue
import com.example.ui.theme.SilverBorder
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextDim
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite
import com.example.ui.theme.WarningAmber

@Composable
fun HomeScreen(
    userProfile: UserProfile?,
    services: List<ServiceItem>,
    announcements: List<Announcement>,
    onTabSelected: (AppTab) -> Unit,
    onAdminClick: () -> Unit,
    onServiceOrderClick: (ServiceItem) -> Unit
) {
    val context = LocalContext.current
    var selectedCategory by remember { mutableStateOf("All") }
    val categories = listOf("All", "Instagram", "YouTube", "Telegram", "Facebook")

    val filteredServices = if (selectedCategory == "All") {
        services.take(6)
    } else {
        services.filter { it.platform.equals(selectedCategory, ignoreCase = true) }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Transparent)
            .padding(bottom = 90.dp) // space for floating navbar
    ) {
        item {
            TopBarHeader(
                title = "MEGA SMM",
                subtitle = "Welcome back, ${userProfile?.displayName ?: "User"}",
                walletBalancePaise = userProfile?.walletBalancePaise ?: 0L,
                onWalletClick = { onTabSelected(AppTab.WALLET) },
                onAdminClick = onAdminClick,
                showAdminButton = userProfile?.isAdmin == true
            )
        }

        // Hero Balance Card
        item {
            Box(modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)) {
                GlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(26.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "AVAILABLE BALANCE",
                                    color = TextMuted,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.sp
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = CurrencyUtils.formatPaise(userProfile?.walletBalancePaise ?: 0L),
                                    color = TextWhite,
                                    fontSize = 30.sp,
                                    fontWeight = FontWeight.ExtraBold
                                )
                            }

                            // Quick Add funds pill
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(20.dp))
                                    .background(
                                        Brush.horizontalGradient(listOf(PrimaryBlue, AccentCyan))
                                    )
                                    .clickable { onTabSelected(AppTab.WALLET) }
                                    .padding(horizontal = 14.dp, vertical = 8.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Filled.Add, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Add Funds", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(18.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            GlassButton(
                                text = "Explore Services",
                                onClick = { onTabSelected(AppTab.SERVICES) },
                                icon = Icons.Filled.ShoppingBag,
                                isSecondary = true,
                                modifier = Modifier.weight(1f)
                            )
                            GlassButton(
                                text = "Track Orders",
                                onClick = { onTabSelected(AppTab.ORDERS) },
                                icon = Icons.Filled.TrendingUp,
                                isSecondary = false,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }
        }

        // Active Announcement Banner
        val activeAnnouncement = announcements.firstOrNull()
        if (activeAnnouncement != null) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(18.dp))
                            .background(Color(0x33FFB800))
                            .border(1.dp, CrownGold.copy(alpha = 0.4f), RoundedCornerShape(18.dp))
                            .padding(14.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(CircleShape)
                                    .background(CrownGold.copy(alpha = 0.2f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Filled.Campaign, contentDescription = null, tint = CrownGold, modifier = Modifier.size(18.dp))
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(activeAnnouncement.title, color = TextWhite, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                Text(activeAnnouncement.message, color = TextMuted, fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        }

        // Platform Filter Pills
        item {
            Column(modifier = Modifier.padding(top = 16.dp)) {
                Text(
                    text = "Platforms",
                    color = TextWhite,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp)
                )
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 20.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(categories) { cat ->
                        GlowingPillButton(
                            text = cat,
                            active = cat == selectedCategory,
                            onClick = { selectedCategory = cat }
                        )
                    }
                }
            }
        }

        // Services Header
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 20.dp, end = 20.dp, top = 22.dp, bottom = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (selectedCategory == "All") "Popular Growth Packages" else "$selectedCategory Services",
                    color = TextWhite,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "View All",
                    color = AccentCyan,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.clickable { onTabSelected(AppTab.SERVICES) }
                )
            }
        }

        // Services list items
        items(filteredServices) { service ->
            Box(modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp)) {
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        PlatformIconBadge(platform = service.platform)
                        Spacer(modifier = Modifier.width(14.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = service.name,
                                color = TextWhite,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 13.sp
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "${CurrencyUtils.formatPaise(service.pricePerThousandPaise)} per 1,000",
                                color = AccentCyan,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                            Text(
                                text = service.deliveryInfo,
                                color = TextDim,
                                fontSize = 10.sp
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(14.dp))
                                .background(PrimaryBlue.copy(alpha = 0.25f))
                                .border(1.dp, PrimaryBlue, RoundedCornerShape(14.dp))
                                .clickable { onServiceOrderClick(service) }
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text("Order", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        // Official Instagram Support Card (strictly Instagram only as requested)
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 14.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(22.dp))
                        .background(Color(0x33833AB4))
                        .border(1.dp, Color(0x66FD1D1D), RoundedCornerShape(22.dp))
                        .clickable {
                            try {
                                val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://instagram.com/megasmmindia"))
                                context.startActivity(intent)
                            } catch (e: Exception) {
                                Toast.makeText(context, "Instagram: @megasmmindia", Toast.LENGTH_LONG).show()
                            }
                        }
                        .padding(18.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(Brush.linearGradient(InstagramGradient)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("IG", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
                        }
                        Spacer(modifier = Modifier.width(14.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Official Support on Instagram", color = TextWhite, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                            Text("Direct DM @megasmmindia for queries & UPI confirmation", color = TextMuted, fontSize = 11.sp)
                        }
                    }
                }
            }
        }
    }
}
