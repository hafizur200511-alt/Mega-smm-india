package com.example.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

// Premium Liquid Glass Cyber-Blue & Navy Palette - iOS 26 Liquid Glass Edition
val BackgroundDark = Color(0xFF020612)
val BackgroundDarkSecondary = Color(0xFF070F24)
val CardBackground = Color(0xFF0B1736)
val CardBackgroundGlass = Color(0xCC0D1B3E)
val CardBackgroundGlassSubtle = Color(0x8008122B)

// Core Brand Accents
val PrimaryBlue = Color(0xFF0072FE)
val SecondaryBlue = Color(0xFF388BFD)
val AccentCyan = Color(0xFF00F5FF)
val ElectricBlue = Color(0xFF1E90FF)
val Silver = Color(0xFFE2E8F0)
val SilverBorder = Color(0x33CBD5E1)
val SilverBorderHighlight = Color(0x66FFFFFF)

// Typography Palette
val TextWhite = Color(0xFFFFFFFF)
val TextMuted = Color(0xFF94A3B8)
val TextDim = Color(0xFF64748B)

// Status Indicators
val SuccessGreen = Color(0xFF10B981)
val WarningAmber = Color(0xFFF59E0B)
val ErrorRed = Color(0xFFEF4444)
val InfoBlue = Color(0xFF3B82F6)
val CrownGold = Color(0xFFFFB800)

// Luxury Emerald Green & Gold Suite
val EmeraldGreen = Color(0xFF10B981)
val EmeraldGreenLight = Color(0xFF34D399)
val EmeraldGreenDark = Color(0xFF065F46)
val EmeraldGlow = Color(0x4010B981)
val LuxuryGold = Color(0xFFFFB800)
val LuxuryGoldLight = Color(0xFFFCD34D)
val LuxuryCardBackground = Color(0xEA030A14)
val LuxuryInputBackground = Color(0x66081424)
val LuxuryEmeraldButtonGradient = Brush.horizontalGradient(
    colors = listOf(Color(0xFF059669), Color(0xFF10B981))
)
val LuxuryEmeraldBorder = Brush.linearGradient(
    colors = listOf(Color(0x9910B981), Color(0x3334D399), Color(0x1AFFFFFF))
)
val LuxuryGoldBorder = Brush.linearGradient(
    colors = listOf(Color(0x99FFB800), Color(0x3310B981), Color(0x40FFFFFF))
)

// Social Platforms
val InstagramGradient = listOf(
    Color(0xFF833AB4),
    Color(0xFFFD1D1D),
    Color(0xFFFCB045)
)
val YouTubeRed = Color(0xFFFF0000)
val FacebookBlue = Color(0xFF1877F2)
val TelegramCyan = Color(0xFF24A1DE)

// Interactive & Gradient Brushes
val PrimaryButtonGradient = Brush.horizontalGradient(
    colors = listOf(Color(0xFF0052D4), Color(0xFF00C6FF))
)

val GlassCardGlow = Color(0x4000C6FF)

// iOS 26 Liquid Glass Tokens
val LiquidCyanOrb = Color(0xFF00E5FF)
val LiquidPurpleOrb = Color(0xFF7928CA)
val LiquidElectricBlue = Color(0xFF0070F3)
val LiquidPinkOrb = Color(0xFFFF0080)
val LiquidGlassSurface = Color(0x2E0B1938)
val LiquidGlassSurfaceLight = Color(0x4D122654)

val LiquidGlassSpecularBorder = Brush.linearGradient(
    colors = listOf(
        Color(0x99FFFFFF),
        Color(0x4000F5FF),
        Color(0x1A0072FE),
        Color(0x66FFFFFF)
    )
)

val LiquidDynamicIslandBrush = Brush.verticalGradient(
    colors = listOf(
        Color(0xE60A1530),
        Color(0xF2030818)
    )
)
