package com.example

enum class ScreenState {
    SPLASH,
    AUTH,
    MAIN,
    ADMIN
}
