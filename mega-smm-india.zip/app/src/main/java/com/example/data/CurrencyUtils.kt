package com.example.data

import java.text.NumberFormat
import java.util.Locale

object CurrencyUtils {
    private val inrFormat = NumberFormat.getCurrencyInstance(Locale("en", "IN")).apply {
        maximumFractionDigits = 2
        minimumFractionDigits = 2
    }

    fun formatPaise(paise: Long): String {
        val rupees = paise / 100.0
        val formatted = inrFormat.format(rupees)
        return formatted.replace("INR", "₹").trim()
    }

    fun parseRupeesToPaise(input: String): Long? {
        val clean = input.trim().replace(",", "")
        val doubleVal = clean.toDoubleOrNull() ?: return null
        if (doubleVal < 0 || doubleVal.isNaN() || doubleVal.isInfinite()) return null
        return (doubleVal * 100.0 + 0.5).toLong()
    }

    fun formatPaiseForUpi(paise: Long): String {
        val rupees = paise / 100.0
        return String.format(Locale.US, "%.2f", rupees)
    }

    fun calculateOrderPricePaise(quantity: Int, pricePerThousandPaise: Long): Long {
        if (quantity <= 0 || pricePerThousandPaise <= 0) return 0L
        return ((quantity.toDouble() / 1000.0) * pricePerThousandPaise + 0.5).toLong()
    }
}
