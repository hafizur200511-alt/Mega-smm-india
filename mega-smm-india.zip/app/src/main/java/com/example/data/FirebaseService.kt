package com.example.data

import android.content.Context
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import com.example.model.Announcement
import com.example.model.Order
import com.example.model.PaymentRequest
import com.example.model.ServiceItem
import com.example.model.UpiSettings
import com.example.model.UserProfile
import com.example.model.WalletTransaction
import com.google.firebase.auth.AuthCredential
import com.google.firebase.auth.AuthResult
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.userProfileChangeRequest
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.util.UUID

object FirebaseService {
    val auth: FirebaseAuth by lazy { FirebaseAuth.getInstance() }
    val firestore: FirebaseFirestore by lazy { FirebaseFirestore.getInstance() }

    val currentUser: FirebaseUser?
        get() = auth.currentUser

    // Trusted initial owner bootstrap email for security bootstrap prior to custom claims
    val INITIAL_BOOTSTRAP_ADMIN_EMAILS = setOf(
        "hafizur200511@gmail.com",
        "admin@megasmm.in",
        "admin@megasmm.com"
    )

    val DEFAULT_SERVICES = listOf(
        ServiceItem(
            id = "IG-FOL-01",
            name = "Instagram Followers [Non-Drop • High Quality]",
            platform = "Instagram",
            category = "Followers",
            description = "Real-looking Indian and international profiles with posts. Lifetime non-drop guarantee.",
            pricePerThousandPaise = 14500L,
            minQuantity = 50,
            maxQuantity = 50000,
            deliveryInfo = "Speed: 5K/day • Start: 0-15 mins • Refill: 30 Days"
        ),
        ServiceItem(
            id = "IG-LIK-01",
            name = "Instagram Likes [Ultra Fast • Real Indian]",
            platform = "Instagram",
            category = "Likes",
            description = "Instant delivery of likes from active Indian users with custom posts and stories.",
            pricePerThousandPaise = 4200L,
            minQuantity = 50,
            maxQuantity = 100000,
            deliveryInfo = "Speed: 20K/hour • Instant Start • 100% Safe"
        ),
        ServiceItem(
            id = "IG-REEL-01",
            name = "Instagram Reel Views + Viral Reach Boost",
            platform = "Instagram",
            category = "Views",
            description = "High retention reel views that boost explore page algorithm placement.",
            pricePerThousandPaise = 1800L,
            minQuantity = 100,
            maxQuantity = 500000,
            deliveryInfo = "Speed: 100K/day • Instant Start"
        ),
        ServiceItem(
            id = "YT-SUB-01",
            name = "YouTube Subscribers [Non-Drop Monetization Safe]",
            platform = "YouTube",
            category = "Subscribers",
            description = "Channel growth booster. Safe for channel monetization with genuine accounts.",
            pricePerThousandPaise = 65000L,
            minQuantity = 50,
            maxQuantity = 5000,
            deliveryInfo = "Speed: 100-300/day natural pacing • Refill: Lifetime"
        ),
        ServiceItem(
            id = "YT-VIEW-01",
            name = "YouTube Views [Suggested Videos • High Retention]",
            platform = "YouTube",
            category = "Views",
            description = "Over 3-5 minute average retention. Safe for AdSense and monetization.",
            pricePerThousandPaise = 24000L,
            minQuantity = 500,
            maxQuantity = 100000,
            deliveryInfo = "Speed: 2K-5K/day • Start: 1 hour"
        ),
        ServiceItem(
            id = "TG-MEM-01",
            name = "Telegram Channel / Group Members [0% Drop]",
            platform = "Telegram",
            category = "Members",
            description = "Permanent Telegram subscribers for channels or discussion groups.",
            pricePerThousandPaise = 9500L,
            minQuantity = 100,
            maxQuantity = 20000,
            deliveryInfo = "Speed: 10K/day • Instant Delivery"
        ),
        ServiceItem(
            id = "FB-FOL-01",
            name = "Facebook Page Followers + Likes",
            platform = "Facebook",
            category = "Followers",
            description = "Genuine page followers to build brand credibility and community authority.",
            pricePerThousandPaise = 18000L,
            minQuantity = 100,
            maxQuantity = 25000,
            deliveryInfo = "Speed: 1K-3K/day • 30 Days Refill"
        )
    )

    // =========================================================================
    // Real Firebase Authentication Methods
    // =========================================================================

    suspend fun signInWithEmailAndPassword(email: String, pass: String): AuthResult {
        val result = auth.signInWithEmailAndPassword(email.trim(), pass).await()
        val user = result.user ?: throw IllegalStateException("Authentication failed: user is null")
        createOrUpdateUserProfile(user)
        return result
    }

    suspend fun registerWithEmailAndPassword(email: String, pass: String, displayName: String): AuthResult {
        val result = auth.createUserWithEmailAndPassword(email.trim(), pass).await()
        val user = result.user ?: throw IllegalStateException("Registration failed: user is null")
        val cleanName = displayName.trim().ifBlank { email.substringBefore("@") }
        try {
            user.updateProfile(userProfileChangeRequest { this.displayName = cleanName }).await()
        } catch (ignored: Exception) {}
        createOrUpdateUserProfile(user, displayName = cleanName)
        return result
    }

    suspend fun sendPasswordResetEmail(email: String) {
        auth.sendPasswordResetEmail(email.trim()).await()
    }

    suspend fun signInWithCredential(credential: AuthCredential): AuthResult {
        val result = auth.signInWithCredential(credential).await()
        val user = result.user ?: throw IllegalStateException("Google sign-in failed: user is null")
        createOrUpdateUserProfile(user)
        return result
    }

    fun signOut(context: Context, onComplete: () -> Unit = {}) {
        try {
            auth.signOut()
        } catch (ignored: Exception) {}

        // Clear Credential Manager session state
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val credentialManager = CredentialManager.create(context)
                credentialManager.clearCredentialState(ClearCredentialStateRequest())
            } catch (ignored: Exception) {}
            launch(Dispatchers.Main) {
                onComplete()
            }
        }
    }

    // =========================================================================
    // Secure Admin Authorization
    // =========================================================================

    fun isUserAdmin(profile: UserProfile?): Boolean {
        if (profile == null) return false
        val email = profile.email.lowercase()
        return profile.isAdmin || INITIAL_BOOTSTRAP_ADMIN_EMAILS.contains(email)
    }

    suspend fun verifyAdminAccess(user: FirebaseUser?): Boolean {
        if (user == null) return false
        val email = (user.email ?: "").lowercase()
        if (INITIAL_BOOTSTRAP_ADMIN_EMAILS.contains(email)) return true

        return try {
            // Check Firebase custom claims first (from token)
            val tokenResult = user.getIdToken(false).await()
            val claims = tokenResult.claims
            if (claims["admin"] == true) return true

            // Check Firestore protected user document
            val snap = firestore.collection("users").document(user.uid).get().await()
            snap.getBoolean("isAdmin") == true
        } catch (e: Exception) {
            false
        }
    }

    // =========================================================================
    // User Profile Lifecycle (Preserves balances and orders)
    // =========================================================================

    suspend fun createOrUpdateUserProfile(user: FirebaseUser, displayName: String? = null) {
        val uid = user.uid
        val docRef = firestore.collection("users").document(uid)
        try {
            val snapshot = docRef.get().await()
            val email = user.email ?: ""
            val isInitialAdmin = INITIAL_BOOTSTRAP_ADMIN_EMAILS.contains(email.lowercase())

            if (!snapshot.exists()) {
                // New user registration profile
                val initialName = displayName ?: user.displayName ?: email.substringBefore("@").ifBlank { "Customer" }
                val newProfile = UserProfile(
                    uid = uid,
                    email = email,
                    displayName = initialName,
                    photoUrl = user.photoUrl?.toString() ?: "",
                    walletBalancePaise = 0L,
                    totalOrders = 0,
                    isAdmin = isInitialAdmin,
                    isSuspended = false,
                    createdAt = System.currentTimeMillis()
                )
                docRef.set(newProfile).await()
            } else {
                // Existing user profile: PRESERVE walletBalancePaise, totalOrders, createdAt, isAdmin!
                val updates = mutableMapOf<String, Any>()
                if (email.isNotBlank()) updates["email"] = email
                val updatedName = displayName ?: user.displayName
                if (!updatedName.isNullOrBlank()) updates["displayName"] = updatedName
                val photo = user.photoUrl?.toString()
                if (!photo.isNullOrBlank()) updates["photoUrl"] = photo
                if (isInitialAdmin && snapshot.getBoolean("isAdmin") != true) {
                    updates["isAdmin"] = true
                }
                if (updates.isNotEmpty()) {
                    docRef.set(updates, SetOptions.merge()).await()
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun observeUserProfile(uid: String): Flow<UserProfile?> = callbackFlow {
        if (uid.isBlank()) {
            trySend(null)
            awaitClose {}
            return@callbackFlow
        }

        val listener = firestore.collection("users").document(uid)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    trySend(null)
                    return@addSnapshotListener
                }
                if (snapshot != null && snapshot.exists()) {
                    val p = snapshot.toObject(UserProfile::class.java)
                    trySend(p)
                } else {
                    trySend(null)
                }
            }
        awaitClose { listener.remove() }
    }

    // =========================================================================
    // Services Catalogue
    // =========================================================================

    fun observeServices(): Flow<List<ServiceItem>> = callbackFlow {
        val listener = firestore.collection("services")
            .addSnapshotListener { snapshot, error ->
                if (error != null || snapshot == null || snapshot.isEmpty) {
                    trySend(DEFAULT_SERVICES)
                    return@addSnapshotListener
                }
                val list = snapshot.toObjects(ServiceItem::class.java)
                trySend(if (list.isEmpty()) DEFAULT_SERVICES else list.sortedBy { it.category })
            }
        awaitClose { listener.remove() }
    }

    suspend fun seedDefaultServicesIfEmpty() {
        try {
            val snap = firestore.collection("services").limit(1).get().await()
            if (snap.isEmpty) {
                for (s in DEFAULT_SERVICES) {
                    firestore.collection("services").document(s.id).set(s).await()
                }
            }
        } catch (ignored: Exception) {}
    }

    suspend fun saveService(service: ServiceItem) {
        val id = if (service.id.isBlank()) UUID.randomUUID().toString() else service.id
        val item = service.copy(id = id, updatedAt = System.currentTimeMillis())
        try {
            firestore.collection("services").document(id).set(item).await()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    suspend fun toggleServiceActive(serviceId: String, currentStatus: Boolean) {
        try {
            firestore.collection("services").document(serviceId)
                .update("isActive", !currentStatus).await()
        } catch (ignored: Exception) {}
    }

    suspend fun deleteService(serviceId: String) {
        try {
            firestore.collection("services").document(serviceId).delete().await()
        } catch (ignored: Exception) {}
    }

    // =========================================================================
    // Orders
    // =========================================================================

    fun observeUserOrders(userId: String): Flow<List<Order>> = callbackFlow {
        if (userId.isBlank()) {
            trySend(emptyList())
            awaitClose {}
            return@callbackFlow
        }
        val listener = firestore.collection("orders")
            .whereEqualTo("userId", userId)
            .addSnapshotListener { snapshot, error ->
                if (error != null || snapshot == null) {
                    trySend(emptyList())
                    return@addSnapshotListener
                }
                val list = snapshot.toObjects(Order::class.java)
                trySend(list.sortedByDescending { it.createdAt })
            }
        awaitClose { listener.remove() }
    }

    fun observeAllOrders(): Flow<List<Order>> = callbackFlow {
        val listener = firestore.collection("orders")
            .addSnapshotListener { snapshot, error ->
                if (error != null || snapshot == null) {
                    trySend(emptyList())
                    return@addSnapshotListener
                }
                val list = snapshot.toObjects(Order::class.java)
                trySend(list.sortedByDescending { it.createdAt })
            }
        awaitClose { listener.remove() }
    }

    suspend fun placeOrder(
        userId: String,
        userEmail: String,
        serviceId: String,
        targetUrl: String,
        quantity: Int
    ): Result<Order> {
        val service = DEFAULT_SERVICES.find { it.id == serviceId }
            ?: return Result.failure(Exception("Service not found"))
        val totalPaise = CurrencyUtils.calculateOrderPricePaise(quantity, service.pricePerThousandPaise)

        // Verify balance in Firestore before placing order
        val userDoc = firestore.collection("users").document(userId).get().await()
        val currentBalance = userDoc.getLong("walletBalancePaise") ?: 0L
        if (currentBalance < totalPaise) {
            return Result.failure(Exception("Insufficient wallet balance. Please add funds."))
        }

        val order = Order(
            id = "ORD-" + System.currentTimeMillis().toString().takeLast(6),
            userId = userId,
            userEmail = userEmail,
            serviceId = service.id,
            serviceName = service.name,
            platform = service.platform,
            targetUrl = targetUrl,
            quantity = quantity,
            totalAmountPaise = totalPaise,
            status = "PENDING",
            createdAt = System.currentTimeMillis(),
            updatedAt = System.currentTimeMillis()
        )

        // Atomic transaction or update to deduct balance and record order
        try {
            firestore.collection("orders").document(order.id).set(order).await()
            firestore.collection("users").document(userId).update(
                mapOf(
                    "walletBalancePaise" to (currentBalance - totalPaise),
                    "totalOrders" to ((userDoc.getLong("totalOrders") ?: 0L) + 1)
                )
            ).await()
        } catch (e: Exception) {
            return Result.failure(e)
        }

        return Result.success(order)
    }

    suspend fun updateOrderStatus(orderId: String, newStatus: String, notes: String = "") {
        try {
            firestore.collection("orders").document(orderId)
                .update(
                    mapOf(
                        "status" to newStatus,
                        "notes" to notes,
                        "updatedAt" to System.currentTimeMillis()
                    )
                ).await()
        } catch (ignored: Exception) {}
    }

    // =========================================================================
    // Payment Requests & UPI Deposits
    // =========================================================================

    fun observeUserPaymentRequests(userId: String): Flow<List<PaymentRequest>> = callbackFlow {
        if (userId.isBlank()) {
            trySend(emptyList())
            awaitClose {}
            return@callbackFlow
        }
        val listener = firestore.collection("payment_requests")
            .whereEqualTo("userId", userId)
            .addSnapshotListener { snapshot, error ->
                if (error != null || snapshot == null) {
                    trySend(emptyList())
                    return@addSnapshotListener
                }
                val list = snapshot.toObjects(PaymentRequest::class.java)
                trySend(list.sortedByDescending { it.createdAt })
            }
        awaitClose { listener.remove() }
    }

    fun observeAllPaymentRequests(): Flow<List<PaymentRequest>> = callbackFlow {
        val listener = firestore.collection("payment_requests")
            .addSnapshotListener { snapshot, error ->
                if (error != null || snapshot == null) {
                    trySend(emptyList())
                    return@addSnapshotListener
                }
                val list = snapshot.toObjects(PaymentRequest::class.java)
                trySend(list.sortedByDescending { it.createdAt })
            }
        awaitClose { listener.remove() }
    }

    suspend fun submitPaymentRequest(
        userId: String,
        userEmail: String,
        amountPaise: Long,
        upiIdUsed: String,
        transactionReference: String
    ): Result<PaymentRequest> {
        val req = PaymentRequest(
            id = "REQ-" + System.currentTimeMillis().toString().takeLast(6),
            userId = userId,
            userEmail = userEmail,
            amountPaise = amountPaise,
            upiIdUsed = upiIdUsed,
            transactionReference = transactionReference,
            status = "PENDING",
            createdAt = System.currentTimeMillis()
        )
        try {
            firestore.collection("payment_requests").document(req.id).set(req).await()
        } catch (e: Exception) {
            return Result.failure(e)
        }
        return Result.success(req)
    }

    suspend fun approvePaymentRequest(requestId: String, adminId: String): Result<Unit> {
        try {
            val reqDoc = firestore.collection("payment_requests").document(requestId).get().await()
            if (!reqDoc.exists()) return Result.failure(Exception("Request not found"))
            val targetUserId = reqDoc.getString("userId") ?: ""
            val amountPaise = reqDoc.getLong("amountPaise") ?: 0L

            firestore.collection("payment_requests").document(requestId)
                .update(
                    mapOf(
                        "status" to "APPROVED",
                        "reviewedBy" to adminId,
                        "reviewedAt" to System.currentTimeMillis()
                    )
                ).await()

            if (targetUserId.isNotBlank() && amountPaise > 0L) {
                val userDoc = firestore.collection("users").document(targetUserId).get().await()
                val currentBalance = userDoc.getLong("walletBalancePaise") ?: 0L
                firestore.collection("users").document(targetUserId)
                    .update("walletBalancePaise", currentBalance + amountPaise)
                    .await()

                // Record transaction
                val txn = WalletTransaction(
                    id = "TXN-" + System.currentTimeMillis().toString().takeLast(6),
                    userId = targetUserId,
                    amountPaise = amountPaise,
                    type = "CREDIT",
                    description = "UPI Deposit Verified (Ref: ${reqDoc.getString("transactionReference") ?: "Direct"})",
                    timestamp = System.currentTimeMillis()
                )
                firestore.collection("transactions").document(txn.id).set(txn).await()
            }
        } catch (e: Exception) {
            return Result.failure(e)
        }
        return Result.success(Unit)
    }

    suspend fun rejectPaymentRequest(requestId: String, reason: String): Result<Unit> {
        try {
            firestore.collection("payment_requests").document(requestId)
                .update(
                    mapOf(
                        "status" to "REJECTED",
                        "rejectionReason" to reason,
                        "reviewedAt" to System.currentTimeMillis()
                    )
                ).await()
        } catch (e: Exception) {
            return Result.failure(e)
        }
        return Result.success(Unit)
    }

    // =========================================================================
    // Wallet Transactions
    // =========================================================================

    fun observeUserTransactions(userId: String): Flow<List<WalletTransaction>> = callbackFlow {
        if (userId.isBlank()) {
            trySend(emptyList())
            awaitClose {}
            return@callbackFlow
        }
        val listener = firestore.collection("transactions")
            .whereEqualTo("userId", userId)
            .addSnapshotListener { snapshot, error ->
                if (error != null || snapshot == null) {
                    trySend(emptyList())
                    return@addSnapshotListener
                }
                val list = snapshot.toObjects(WalletTransaction::class.java)
                trySend(list.sortedByDescending { it.timestamp })
            }
        awaitClose { listener.remove() }
    }

    // =========================================================================
    // UPI & App Settings
    // =========================================================================

    fun observeUpiSettings(): Flow<UpiSettings> = callbackFlow {
        val defaultSettings = UpiSettings()
        val listener = firestore.collection("settings").document("upi")
            .addSnapshotListener { snapshot, error ->
                if (error != null || snapshot == null || !snapshot.exists()) {
                    trySend(defaultSettings)
                    return@addSnapshotListener
                }
                val settings = snapshot.toObject(UpiSettings::class.java) ?: defaultSettings
                trySend(settings)
            }
        awaitClose { listener.remove() }
    }

    suspend fun saveUpiSettings(settings: UpiSettings) {
        try {
            firestore.collection("settings").document("upi").set(settings).await()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    // =========================================================================
    // Announcements
    // =========================================================================

    fun observeAnnouncements(): Flow<List<Announcement>> = callbackFlow {
        val defaultAnnouncements = listOf(
            Announcement(
                id = "ann-1",
                title = "⚡ Flash Discount: 20% Off Instagram Services",
                message = "Enjoy high speed Instagram followers and likes at reduced rates all week long!",
                type = "PROMO"
            ),
            Announcement(
                id = "ann-2",
                title = "UPI Instant Verification Active",
                message = "Pay using Paytm / PhonePe / GPay. Enter the 12-digit UTR in Balance to recharge.",
                type = "INFO"
            )
        )
        val listener = firestore.collection("announcements")
            .whereEqualTo("isActive", true)
            .addSnapshotListener { snapshot, error ->
                if (error != null || snapshot == null || snapshot.isEmpty) {
                    trySend(defaultAnnouncements)
                    return@addSnapshotListener
                }
                val list = snapshot.toObjects(Announcement::class.java)
                trySend(if (list.isEmpty()) defaultAnnouncements else list)
            }
        awaitClose { listener.remove() }
    }

    suspend fun createAnnouncement(title: String, message: String, type: String = "INFO") {
        val ann = Announcement(
            id = "ann-" + System.currentTimeMillis().toString().takeLast(6),
            title = title,
            message = message,
            type = type,
            isActive = true,
            createdAt = System.currentTimeMillis()
        )
        try {
            firestore.collection("announcements").document(ann.id).set(ann).await()
        } catch (ignored: Exception) {}
    }

    suspend fun deleteAnnouncement(announcementId: String) {
        try {
            firestore.collection("announcements").document(announcementId).delete().await()
        } catch (ignored: Exception) {}
    }

    // =========================================================================
    // Admin User Management
    // =========================================================================

    fun observeAllUsers(): Flow<List<UserProfile>> = callbackFlow {
        val listener = firestore.collection("users")
            .addSnapshotListener { snapshot, error ->
                if (error != null || snapshot == null) {
                    trySend(emptyList())
                    return@addSnapshotListener
                }
                val list = snapshot.toObjects(UserProfile::class.java)
                trySend(list)
            }
        awaitClose { listener.remove() }
    }

    suspend fun toggleUserSuspension(userId: String, currentSuspended: Boolean) {
        try {
            firestore.collection("users").document(userId)
                .update("isSuspended", !currentSuspended).await()
        } catch (ignored: Exception) {}
    }
}
