package com.example.data

import android.graphics.Bitmap
import android.graphics.Color
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel
import java.net.URLEncoder
import java.util.EnumMap

object QrCodeGenerator {
    fun buildUpiUri(upiId: String, payeeName: String, amountPaise: Long, transactionNote: String): String {
        val amountStr = CurrencyUtils.formatPaiseForUpi(amountPaise)
        val encodedPn = URLEncoder.encode(payeeName.trim(), "UTF-8").replace("+", "%20")
        val encodedTn = URLEncoder.encode(transactionNote.trim(), "UTF-8").replace("+", "%20")
        return "upi://pay?pa=${upiId.trim()}&pn=$encodedPn&am=$amountStr&cu=INR&tn=$encodedTn"
    }

    fun generateQrBitmap(
        content: String,
        size: Int = 512,
        darkColor: Int = Color.rgb(5, 11, 24),
        lightColor: Int = Color.WHITE
    ): Bitmap? {
        if (content.isBlank()) return null
        return try {
            val hints = EnumMap<EncodeHintType, Any>(EncodeHintType::class.java).apply {
                put(EncodeHintType.CHARACTER_SET, "UTF-8")
                put(EncodeHintType.MARGIN, 2)
                put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.H)
            }
            val bitMatrix = QRCodeWriter().encode(content, BarcodeFormat.QR_CODE, size, size, hints)
            val width = bitMatrix.width
            val height = bitMatrix.height
            val pixels = IntArray(width * height)
            for (y in 0 until height) {
                val offset = y * width
                for (x in 0 until width) {
                    pixels[offset + x] = if (bitMatrix.get(x, y)) darkColor else lightColor
                }
            }
            val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            bitmap.setPixels(pixels, 0, width, 0, 0, width, height)
            bitmap
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }
}
